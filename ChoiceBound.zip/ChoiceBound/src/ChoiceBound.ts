/* eslint-disable @typescript-eslint/brace-style */
/*
 * author: PureRussianVodka,
 * Version: 1.0.0
 * Compatible with: SPT 3.10.5
 * Date: 07/28/2024
 */

//Dependencies
import { DependencyContainer } from "tsyringe";
//Loaders
import { IPostDBLoadMod } from "@spt/models/external/IPostDBLoadMod";
//Utils
import { ILogger } from "@spt/models/spt/utils/ILogger";
import { VFS } from "@spt/utils/VFS";
import { jsonc } from "jsonc";

//Profiles
import { MoneyPower } from "./Profiles/1_MoneyPower";         // Updated import
import { Allegiance } from "./Profiles/2_Allegiance";         // Updated import
import { Storage } from "./Profiles/3_Storage";               //Updated Import
import { Security } from "./Profiles/4_Security";             // in the works

import path from "path";

class CustomProfiles implements IPostDBLoadMod {
    private modInfo = require("../package.json");
    private logger: ILogger;
    private vfs: VFS;

    public postDBLoad(container: DependencyContainer): void {
        this.logger = container.resolve<ILogger>("WinstonLogger");
        this.vfs = container.resolve<VFS>("VFS");

        const profilesConfig = this.loadConfig();
        const profileInstances = this.createProfileInstances();

        this.handleProfile(profilesConfig.ChoiceBoundProfiles, profileInstances, container);
    }

    private loadConfig() {
        const configPath = path.resolve(__dirname, "../config/config.jsonc");
        return jsonc.parse(this.vfs.readFile(configPath)).Profiles;
    }

    private createProfileInstances() {
        return {
            moneypower: new MoneyPower(),  // Updated instance
            allegiance: new Allegiance(),  // Updated instance
            storage: new Storage(),        // Updated instance
            security: new Security()       // in the works
        };
    }

    private handleProfile(config: any, instances: any, container: DependencyContainer) {
        for (const [key, value] of Object.entries(config)) {
            if (typeof value === "boolean" && value === true) {
                const instanceMethod = `${key}_profile`;
                if (typeof instances[key]?.[instanceMethod] === "function") {
                    instances[key][instanceMethod](container);
                }
            }
        }
    }
}

module.exports = { mod: new CustomProfiles() };