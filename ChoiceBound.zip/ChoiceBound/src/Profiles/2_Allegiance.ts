/* eslint-disable @typescript-eslint/naming-convention */

/*
 * author: PureRussianVodka,
 * Version: 1.0.0
 * Compatible with: SPT 3.9.4
 * Date: 07/28/2024
 */

import { DependencyContainer } from "tsyringe";
import { ILogger } from "@spt/models/spt/utils/ILogger";
import { DatabaseServer } from "@spt/servers/DatabaseServer";
import { LogTextColor } from "@spt/models/spt/logging/LogTextColor";
import { LogBackgroundColor } from "@spt/models/spt/logging/LogBackgroundColor";


export class Allegiance {
    private logger: ILogger;

    public allegiance_profile(container: DependencyContainer): void 
    {
        this.logger = container.resolve<ILogger>("WinstonLogger");
        const profiles = container.resolve<DatabaseServer>("DatabaseServer").getTables().templates.profiles;

        //logic for Allegiance=Power profile
        
        profiles["Allegiance=Power"] =
        {
            "descriptionLocaleKey": "Start With a 2x3 Secure container, level 2 stash -/+ 0.2 Rep based on which faction you chose",
            "bear": {
                "character": {
                    "TaskConditionCounters": {},
                    "Bonuses": [{
                        "id": "64f5b9e5fa34f11b380756c0",
                        "templateId": "566abbc34bdc2d92178b4576",
                        "type": "StashSize"
                    }
                    ],
                    "Customization": {
                        "Body": "5cc0858d14c02e000c6bea66",
                        "Feet": "5cc085bb14c02e000e67a5c5",
                        "Hands": "5cc0876314c02e000c6bea6b",
                        "Head": "__REPLACEME__"
                    },
                    "Encyclopedia": {
                        "5447a9cd4bdc2dbd208b4567": false,
                        "5448bd6b4bdc2dfc2f8b4569": false,
                        "5448c12b4bdc2d02308b456f": false,
                        "5448fee04bdc2dbc018b4567": false,
                        "5449016a4bdc2d6f028b456f": false,
                        "54491bb74bdc2d09088b4567": false,
                        "544a11ac4bdc2d470e8b456a": false,
                        "544a38634bdc2d58388b4568": false,
                        "544a5cde4bdc2d39388b456b": false,
                        "544fb25a4bdc2dfb738b4567": false,
                        "544fb3364bdc2d34748b456a": false,
                        "544fb37f4bdc2dee738b4567": false,
                        "54527a984bdc2d4e668b4567": false,
                        "557ffd194bdc2d28148b457f": false,
                        "55d355e64bdc2d962f8b4569": false,
                        "55d3632e4bdc2d972f8b4569": false,
                        "55d44fd14bdc2d962f8b456e": false,
                        "55d459824bdc2d892f8b4573": false,
                        "55d4887d4bdc2d962f8b4570": false,
                        "55d4ae6c4bdc2d8b2f8b456e": false,
                        "55d4af3a4bdc2d972f8b456f": false,
                        "55d4b9964bdc2d1d4e8b456e": false,
                        "55d5f46a4bdc2d1b198b4567": false,
                        "55d7217a4bdc2d86028b456d": false,
                        "5645bcc04bdc2d363b8b4572": false,
                        "5648a7494bdc2d9d488b4583": false,
                        "5649ad3f4bdc2df8348b4585": false,
                        "5649be884bdc2d79388b4577": false,
                        "564ca99c4bdc2d16268b4589": false,
                        "566abbc34bdc2d92178b4576": false,
                        "56d59856d2720bd8418b456a": false,
                        "56d59948d2720bb7418b4582": false,
                        "56d59d3ad2720bdb418b4577": false,
                        "56d5a1f7d2720bb3418b456a": false,
                        "56d5a2bbd2720bb8418b456a": true,
                        "56d5a407d2720bb3418b456b": true,
                        "56d5a661d2720bd8418b456b": false,
                        "56d5a77ed2720b90418b4568": false,
                        "56dfef82d2720bbd668b4567": true,
                        "56ea8d2fd2720b7c698b4570": false,
                        "572b7fa524597762b747ce82": false,
                        "57347d7224597744596b4e72": false,
                        "57347da92459774491567cf5": false,
                        "573718ba2459775a75491131": false,
                        "5751a25924597722c463c472": false,
                        "5755356824597772cb798962": false,
                        "5755383e24597772cb798966": false,
                        "57dc2fa62459775949412633": false,
                        "57dc324a24597759501edc20": true,
                        "57dc32dc245977596d4ef3d3": false,
                        "57dc334d245977597164366f": true,
                        "57dc347d245977596754e7a1": false,
                        "58864a4f2459770fcc257101": false,
                        "58d3db5386f77426186285a0": false,
                        "590c5f0d86f77413997acfab": false,
                        "590c661e86f7741e566b646a": false,
                        "5926bb2186f7744b1c6c6e60": false,
                        "5926c0df86f77462f647f764": false,
                        "5926c32286f774616e42de99": false,
                        "5926c36d86f77467a92a8629": false,
                        "5926c3b286f774640d189b6b": false,
                        "5926d2be86f774134d668e4e": false,
                        "5926d3c686f77410de68ebc8": false,
                        "5926e16e86f7742f5a0f7ecb": false,
                        "59d36a0086f7747e673f3946": true,
                        "5a0c27731526d80618476ac4": false,
                        "5aa2a7e8e5b5b00016327c16": false,
                        "5ab8f39486f7745cd93a1cca": false,
                        "5ae30bad5acfc400185c2dc4": false,
                        "5ae30db85acfc408fb139a05": false,
                        "5ae30e795acfc408fb139a0b": false,
                        "5b44c8ea86f7742d1627baf1": false,
                        "5c0e9f2c86f77432297fe0a3": false,
                        "5cadc190ae921500103bb3b6": false,
                        "5cadc1c6ae9215000f2775a4": false,
                        "5cadc2e0ae9215051e1c21e7": false,
                        "5cadc390ae921500126a77f1": false,
                        "5cadc431ae921500113bb8d5": false,
                        "5cadc55cae921500103bb3be": false,
                        "5cadd919ae921500126a77f3": false,
                        "5cadd940ae9215051e1c2316": false,
                        "5d1b371186f774253763a656": false,
                        "5d2f213448f0355009199284": false,
                        "5d403f9186f7743cac3f229b": false,
                        "5e2af47786f7746d404f3aaa": false,
                        "5e2af4a786f7746d3f3c3400": false,
                        "5e4d34ca86f774264f758330": false,
                        "5e831507ea0a7c419c2f9bd9": false,
                        "5e9dcf5986f7746c417435b3": false
                    },
                    "Health": {
                        "BodyParts": {
                            "Chest": {
                                "Health": {
                                    "Current": 85,
                                    "Maximum": 85
                                }
                            },
                            "Head": {
                                "Health": {
                                    "Current": 35,
                                    "Maximum": 35
                                }
                            },
                            "LeftArm": {
                                "Health": {
                                    "Current": 60,
                                    "Maximum": 60
                                }
                            },
                            "LeftLeg": {
                                "Health": {
                                    "Current": 65,
                                    "Maximum": 65
                                }
                            },
                            "RightArm": {
                                "Health": {
                                    "Current": 60,
                                    "Maximum": 60
                                }
                            },
                            "RightLeg": {
                                "Health": {
                                    "Current": 65,
                                    "Maximum": 65
                                }
                            },
                            "Stomach": {
                                "Health": {
                                    "Current": 70,
                                    "Maximum": 70
                                }
                            }
                        },
                        "Energy": {
                            "Current": 100,
                            "Maximum": 100
                        },
                        "Hydration": {
                            "Current": 100,
                            "Maximum": 100
                        },
                        "Temperature": {
                            "Current": 36.6,
                            "Maximum": 40
                        },
                        "UpdateTime": 1736326673
                    },
                    "Hideout": {
                        "Areas": [
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 2,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 3
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 0
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 1
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 2
                            },
                            {
                                "active": false,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    },
                                    {
                                        "locationIndex": 5
                                    },
                                    {
                                        "locationIndex": 6
                                    },
                                    {
                                        "locationIndex": 7
                                    }
                                ],
                                "type": 4
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 5
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    }
                                ],
                                "type": 6
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 7
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 8
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 9
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 10
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 11
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 12
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 13
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 14
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 15
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 16
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": false,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    }
                                ],
                                "type": 17
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 18
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 19
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    },
                                    {
                                        "locationIndex": 5
                                    },
                                    {
                                        "locationIndex": 6
                                    },
                                    {
                                        "locationIndex": 7
                                    },
                                    {
                                        "locationIndex": 8
                                    },
                                    {
                                        "locationIndex": 9
                                    },
                                    {
                                        "locationIndex": 10
                                    },
                                    {
                                        "locationIndex": 11
                                    },
                                    {
                                        "locationIndex": 12
                                    },
                                    {
                                        "locationIndex": 13
                                    },
                                    {
                                        "locationIndex": 14
                                    },
                                    {
                                        "locationIndex": 15
                                    },
                                    {
                                        "locationIndex": 16
                                    },
                                    {
                                        "locationIndex": 17
                                    },
                                    {
                                        "locationIndex": 18
                                    },
                                    {
                                        "locationIndex": 19
                                    },
                                    {
                                        "locationIndex": 20
                                    },
                                    {
                                        "locationIndex": 21
                                    },
                                    {
                                        "locationIndex": 22
                                    },
                                    {
                                        "locationIndex": 23
                                    },
                                    {
                                        "locationIndex": 24
                                    },
                                    {
                                        "locationIndex": 25
                                    },
                                    {
                                        "locationIndex": 26
                                    },
                                    {
                                        "locationIndex": 27
                                    },
                                    {
                                        "locationIndex": 28
                                    },
                                    {
                                        "locationIndex": 29
                                    },
                                    {
                                        "locationIndex": 30
                                    },
                                    {
                                        "locationIndex": 31
                                    },
                                    {
                                        "locationIndex": 32
                                    },
                                    {
                                        "locationIndex": 33
                                    },
                                    {
                                        "locationIndex": 34
                                    },
                                    {
                                        "locationIndex": 35
                                    },
                                    {
                                        "locationIndex": 36
                                    },
                                    {
                                        "locationIndex": 37
                                    },
                                    {
                                        "locationIndex": 38
                                    },
                                    {
                                        "locationIndex": 39
                                    },
                                    {
                                        "locationIndex": 40
                                    },
                                    {
                                        "locationIndex": 41
                                    },
                                    {
                                        "locationIndex": 42
                                    },
                                    {
                                        "locationIndex": 43
                                    },
                                    {
                                        "locationIndex": 44
                                    },
                                    {
                                        "locationIndex": 45
                                    },
                                    {
                                        "locationIndex": 46
                                    },
                                    {
                                        "locationIndex": 47
                                    },
                                    {
                                        "locationIndex": 48
                                    },
                                    {
                                        "locationIndex": 49
                                    }
                                ],
                                "type": 20
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 21
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 22
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 23
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 24
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 25
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 26
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    }
                                ],
                                "type": 27
                            }
                        ],
                        "Improvements": {},
                        "Production": {},
                        "HideoutCounters": null,
                        "Seed": 1988614673,
                        "sptUpdateLastRunTimestamp": 1736326677
                    },
                    "Info": {
                        "AccountType": 0,
                        "BannedState": false,
                        "BannedUntil": 0,
                        "Bans": [],
                        "Experience": 0,
                        "GameVersion": "standard",
                        "IsStreamerModeAvailable": false,
                        "LastTimePlayedAsSavage": 0,
                        "Level": 1,
                        "LowerNickname": "__REPLACEME__",
                        "MemberCategory": 0,
                        "isMigratedSkills": false,
                        "SelectedMemberCategory": 0,
                        "Nickname": "__REPLACEME__",
                        "NicknameChangeDate": 0,
                        "RegistrationDate": "__REPLACEME__",
                        "SavageLockTime": 0,
                        "Settings": {
                            "BotDifficulty": "easy",
                            "Experience": -1,
                            "Role": "assault"
                        },
                        "Side": "Bear",
                        "SquadInviteRestriction": false,
                        "HasCoopExtension": false,
                        "Voice": "__REPLACEME__",
                        "lockedMoveCommands": true
                    },
                    "InsuredItems": [],
                    "Inventory": {
                        "equipment": "745fcb25fc898c3040325627",
                        "fastPanel": {},
                        "hideoutAreaStashes": {},
                        "items": [
                            {
                                "_id": "745fcb25fc898c3040325627",
                                "_tpl": "55d7217a4bdc2d86028b456d"
                            },
                            {
                                "_id": "9cd4a2c4ef26d2f93108da8e",
                                "_tpl": "6401c7b213d9b818bf0e7dd7"
                            },
                            {
                                "_id": "944d91661e2352dc413aeddc",
                                "_tpl": "5857a8b324597729ab0a0e7d",
                                "parentId": "745fcb25fc898c3040325627",
                                "slotId": "SecuredContainer"
                            },
                            {
                                "_id": "52b06a8b20aaa54d5fab1ae4",
                                "_tpl": "627a4e6b255f7527fb05a0f6",
                                "parentId": "745fcb25fc898c3040325627",
                                "slotId": "Pockets"
                            },
                            {
                                "_id": "5fe49cdfa19cac3fa9054115",
                                "_tpl": "5811ce572459770cba1a34ea"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b8",
                                "_tpl": "5963866b86f7747bfa1c4462"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b7",
                                "_tpl": "5963866286f7747bf429b572"
                            },
                            {
                                "_id": "60dca3da42ad9b706b369aca",
                                "_tpl": "602543c13fee350cd564d032"
                            },
                            {
                                "_id": "7f9e26659e65d66138ba6ad9",
                                "_tpl": "564ca99c4bdc2d16268b4589",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 7,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "665f793d6c7804857fd32135",
                                "_tpl": "564ca99c4bdc2d16268b4589",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 9,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "79a2b1ca085deab3b718157f",
                                "_tpl": "5644bd2b4bdc2d3b4c8b4572",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 0,
                                    "r": "Vertical",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "ae977a7b03c5aa66071199ea",
                                "_tpl": "59c6633186f7740cf0493bb9",
                                "parentId": "79a2b1ca085deab3b718157f",
                                "slotId": "mod_gas_block",
                                "upd": {}
                            },
                            {
                                "_id": "36eb10c0962598872adf48d0",
                                "_tpl": "5648b0744bdc2d363b8b4578",
                                "parentId": "ae977a7b03c5aa66071199ea",
                                "slotId": "mod_handguard",
                                "upd": {}
                            },
                            {
                                "_id": "674b8fdc89e11ceb60d1e6d3",
                                "_tpl": "5649aa744bdc2ded0b8b457e",
                                "parentId": "79a2b1ca085deab3b718157f",
                                "slotId": "mod_muzzle",
                                "upd": {}
                            },
                            {
                                "_id": "d645b591a3f6e36af54fdec8",
                                "_tpl": "5649ad3f4bdc2df8348b4585",
                                "parentId": "79a2b1ca085deab3b718157f",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "1ccdc081b5a396d08c7b7959",
                                "_tpl": "5649af094bdc2df8348b4586",
                                "parentId": "79a2b1ca085deab3b718157f",
                                "slotId": "mod_reciever",
                                "upd": {}
                            },
                            {
                                "_id": "9dae6fd9bc8075bf29ae8015",
                                "_tpl": "5649b0544bdc2d1b2b8b458a",
                                "parentId": "79a2b1ca085deab3b718157f",
                                "slotId": "mod_sight_rear",
                                "upd": {}
                            },
                            {
                                "_id": "73eee2fcbdfbb2430bd5477a",
                                "_tpl": "5649b1c04bdc2d16268b457c",
                                "parentId": "79a2b1ca085deab3b718157f",
                                "slotId": "mod_stock",
                                "upd": {}
                            },
                            {
                                "_id": "a10e3a05858bd6b6bfe3870f",
                                "_tpl": "564ca99c4bdc2d16268b4589",
                                "parentId": "79a2b1ca085deab3b718157f",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "1298ed6056adf452207131d3",
                                "_tpl": "5644bd2b4bdc2d3b4c8b4572",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 0,
                                    "r": "Vertical",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "f4e88c259fddcbcb000d62dd",
                                "_tpl": "59c6633186f7740cf0493bb9",
                                "parentId": "1298ed6056adf452207131d3",
                                "slotId": "mod_gas_block",
                                "upd": {}
                            },
                            {
                                "_id": "e1e96bb8d5818d8470f84eea",
                                "_tpl": "5648b0744bdc2d363b8b4578",
                                "parentId": "f4e88c259fddcbcb000d62dd",
                                "slotId": "mod_handguard",
                                "upd": {}
                            },
                            {
                                "_id": "8ceaa2d5e8b54fa7640ab27f",
                                "_tpl": "5649aa744bdc2ded0b8b457e",
                                "parentId": "1298ed6056adf452207131d3",
                                "slotId": "mod_muzzle",
                                "upd": {}
                            },
                            {
                                "_id": "f7ae05a6bc8528ff73a5811f",
                                "_tpl": "5649ad3f4bdc2df8348b4585",
                                "parentId": "1298ed6056adf452207131d3",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "dcbd5fdcf46362ab90e86ab2",
                                "_tpl": "5649af094bdc2df8348b4586",
                                "parentId": "1298ed6056adf452207131d3",
                                "slotId": "mod_reciever",
                                "upd": {}
                            },
                            {
                                "_id": "7ab6240f262e6a724a087af1",
                                "_tpl": "5649b0544bdc2d1b2b8b458a",
                                "parentId": "1298ed6056adf452207131d3",
                                "slotId": "mod_sight_rear",
                                "upd": {}
                            },
                            {
                                "_id": "008c66b36856b9f7ab3248a6",
                                "_tpl": "5649b1c04bdc2d16268b457c",
                                "parentId": "1298ed6056adf452207131d3",
                                "slotId": "mod_stock",
                                "upd": {}
                            },
                            {
                                "_id": "f3d1541d8d5d86274b086e60",
                                "_tpl": "564ca99c4bdc2d16268b4589",
                                "parentId": "4ce8dfd247c31ac9a9bc6ef2",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "3038b60f1cee533d030fbb28",
                                "_tpl": "572b7adb24597762ae139821",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 8,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0a3653d042decb7610853873",
                                "_tpl": "572b7adb24597762ae139821",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 4,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "d32588579ce18ce38918c9da",
                                "_tpl": "572b7adb24597762ae139821",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 6,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "4ce8dfd247c31ac9a9bc6ef2",
                                "_tpl": "5644bd2b4bdc2d3b4c8b4572",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "56403a0c320720b21842e5fe",
                                "_tpl": "59c6633186f7740cf0493bb9",
                                "parentId": "4ce8dfd247c31ac9a9bc6ef2",
                                "slotId": "mod_gas_block",
                                "upd": {}
                            },
                            {
                                "_id": "56653ef32b402b08a9a33964",
                                "_tpl": "5648b0744bdc2d363b8b4578",
                                "parentId": "56403a0c320720b21842e5fe",
                                "slotId": "mod_handguard",
                                "upd": {}
                            },
                            {
                                "_id": "ad04408759134d9c90fa8714",
                                "_tpl": "5649aa744bdc2ded0b8b457e",
                                "parentId": "4ce8dfd247c31ac9a9bc6ef2",
                                "slotId": "mod_muzzle",
                                "upd": {}
                            },
                            {
                                "_id": "12fa48ecbee4619f7b76ff8a",
                                "_tpl": "5649ad3f4bdc2df8348b4585",
                                "parentId": "4ce8dfd247c31ac9a9bc6ef2",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "25095519bf8152e4c3623f70",
                                "_tpl": "5649af094bdc2df8348b4586",
                                "parentId": "4ce8dfd247c31ac9a9bc6ef2",
                                "slotId": "mod_reciever",
                                "upd": {}
                            },
                            {
                                "_id": "6d6a9aca6a5a8652144a0a6d",
                                "_tpl": "5649b0544bdc2d1b2b8b458a",
                                "parentId": "4ce8dfd247c31ac9a9bc6ef2",
                                "slotId": "mod_sight_rear",
                                "upd": {}
                            },
                            {
                                "_id": "f29ccba2cbd8ce1f54a31fe6",
                                "_tpl": "5649b1c04bdc2d16268b457c",
                                "parentId": "4ce8dfd247c31ac9a9bc6ef2",
                                "slotId": "mod_stock",
                                "upd": {}
                            },
                            {
                                "_id": "a8a8aa6546f61e5a446758cc",
                                "_tpl": "564ca99c4bdc2d16268b4589",
                                "parentId": "1298ed6056adf452207131d3",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "f327f953ebbed03c8a74ecc8",
                                "_tpl": "564ca99c4bdc2d16268b4589",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 8,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "89177ec0b6da840e1a6edd4f",
                                "_tpl": "5755356824597772cb798962",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "a1b294f91494be5e8030c03b",
                                "_tpl": "5755356824597772cb798962",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "de890817bb2647fed5dc7369",
                                "_tpl": "5755356824597772cb798962",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "13238628a8167c4d2785d3e2",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "c247a21e24fa4f867d254d8d",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "6e3e9825a04c37b007a5e354",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "f2d240046dd5de4c50c1d74b",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "7f9e26659e65d66138ba6ad9",
                                "slotId": "cartridges",
                                "upd": {
                                    "StackObjectsCount": 30
                                },
                                "location": 0
                            },
                            {
                                "_id": "8d5347b91237d4bc08d0c46b",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "a8a8aa6546f61e5a446758cc",
                                "slotId": "cartridges",
                                "upd": {
                                    "StackObjectsCount": 30
                                },
                                "location": 0
                            },
                            {
                                "_id": "1dabee8ae68e42b2e36cecf1",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 60
                                },
                                "location": {
                                    "x": 5,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "710756b07c23e4ee7e9c1a98",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "f3d1541d8d5d86274b086e60",
                                "slotId": "cartridges",
                                "upd": {
                                    "StackObjectsCount": 30
                                },
                                "location": 0
                            },
                            {
                                "_id": "66a0cc6f01001981295fb963",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "f327f953ebbed03c8a74ecc8",
                                "slotId": "cartridges",
                                "location": 0,
                                "upd": {
                                    "StackObjectsCount": 30
                                }
                            },
                            {
                                "_id": "66a0cc950100198129087216",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "665f793d6c7804857fd32135",
                                "slotId": "cartridges",
                                "location": 0,
                                "upd": {
                                    "StackObjectsCount": 30
                                }
                            },
                            {
                                "_id": "66a0cc9d0100198129dadd74",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "a10e3a05858bd6b6bfe3870f",
                                "slotId": "cartridges",
                                "location": 0,
                                "upd": {
                                    "StackObjectsCount": 30
                                }
                            },
                            {
                                "_id": "15440c3004b8cd1937d847a7",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 60
                                },
                                "location": {
                                    "x": 6,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "a16c2ef0fd2ed52b387b764f",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 60
                                },
                                "location": {
                                    "x": 6,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "fda2af00e03dfa232644cd5c",
                                "_tpl": "5c06c6a80db834001b735491",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "bdb57c1a70e95c059c9e9fca",
                                "_tpl": "6571199565daf6aa960c9b10",
                                "parentId": "fda2af00e03dfa232644cd5c",
                                "slotId": "Helmet_top",
                                "upd": {}
                            },
                            {
                                "_id": "306698e8f2a42bc81de74dc4",
                                "_tpl": "657119d49eb8c145180dbb95",
                                "parentId": "fda2af00e03dfa232644cd5c",
                                "slotId": "Helmet_back",
                                "upd": {}
                            },
                            {
                                "_id": "d83d6680638c6880c515f267",
                                "_tpl": "657119fea330b8c9060f7afc",
                                "parentId": "fda2af00e03dfa232644cd5c",
                                "slotId": "Helmet_ears",
                                "upd": {}
                            },
                            {
                                "_id": "56dc2ec23011b2743d627f48",
                                "_tpl": "5c06c6a80db834001b735491",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "ef160658b0dba75b00d2934f",
                                "_tpl": "6571199565daf6aa960c9b10",
                                "parentId": "56dc2ec23011b2743d627f48",
                                "slotId": "Helmet_top",
                                "upd": {}
                            },
                            {
                                "_id": "a6742de624ccea5e7b81ded3",
                                "_tpl": "657119d49eb8c145180dbb95",
                                "parentId": "56dc2ec23011b2743d627f48",
                                "slotId": "Helmet_back",
                                "upd": {}
                            },
                            {
                                "_id": "a34e6d00aa9682d63310ad89",
                                "_tpl": "657119fea330b8c9060f7afc",
                                "parentId": "56dc2ec23011b2743d627f48",
                                "slotId": "Helmet_ears",
                                "upd": {}
                            },
                            {
                                "_id": "d0ea93255726ebc6ca1c19a6",
                                "_tpl": "5c06c6a80db834001b735491",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 8,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "11439e3e0600de28c49d92ff",
                                "_tpl": "6571199565daf6aa960c9b10",
                                "parentId": "d0ea93255726ebc6ca1c19a6",
                                "slotId": "Helmet_top",
                                "upd": {}
                            },
                            {
                                "_id": "8c089b6521e274ff2341b649",
                                "_tpl": "657119d49eb8c145180dbb95",
                                "parentId": "d0ea93255726ebc6ca1c19a6",
                                "slotId": "Helmet_back",
                                "upd": {}
                            },
                            {
                                "_id": "b97b19e69fce24fadd116286",
                                "_tpl": "657119fea330b8c9060f7afc",
                                "parentId": "d0ea93255726ebc6ca1c19a6",
                                "slotId": "Helmet_ears",
                                "upd": {}
                            },
                            {
                                "_id": "f931eb45f07419801a18f4c4",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 9,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "2788b33ce03c88dfcd32d8e5",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 8,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "2dda82c1f7796d0752400b63",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 9,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "4870507112a5a8d0e1c7f072",
                                "_tpl": "56dff4a2d2720bbd668b456a",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 60
                                },
                                "location": {
                                    "x": 5,
                                    "y": 5,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "8f78430ce291885600fc7117",
                                "_tpl": "5af0548586f7743a532b7e99",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "MedKit": {
                                        "HpResource": 15
                                    }
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 3,
                                    "y": 7,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "b052de6cddd2ef26ff5c3414",
                                "_tpl": "5af0454c86f7746bf20992e8",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "MedKit": {
                                        "HpResource": 5
                                    }
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 3,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "93285f36d90d1c6bd770865e",
                                "_tpl": "590c5d4b86f774784e1b9c45",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 7,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "4fa90733132e610cd665a193",
                                "_tpl": "5e8f3423fd7471236e6e3b64",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "FoodDrink": {
                                        "HpPercent": 60
                                    }
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 6,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "388998c4a094c68e3ee9a314",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 8,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "b1d518722aa1b9a700284f20",
                                "_tpl": "5d02778e86f774203e7dedbe",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "location": {
                                    "x": 4,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            }
                        ],
                        "questRaidItems": "5fe4977574f15b4ad31b66b7",
                        "questStashItems": "5fe4977574f15b4ad31b66b8",
                        "sortingTable": "60dca3da42ad9b706b369aca",
                        "stash": "5fe49cdfa19cac3fa9054115"
                    },
                    "Notes": {
                        "Notes": []
                    },
                    "Quests": [],
                    "RagfairInfo": {
                        "isRatingGrowing": true,
                        "offers": [],
                        "rating": 0.2
                    },
                    "Skills": {
                        "Common": [{
                            "Id": "BotReload",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "BotSound",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Endurance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Strength",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Vitality",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Health",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "StressResistance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Metabolism",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Immunity",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Perception",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Intellect",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Attention",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Charisma",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Memory",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Pistol",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Revolver",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "SMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Assault",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Shotgun",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Sniper",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "LMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Launcher",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AttachedLauncher",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Throwing",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Melee",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "DMR",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "RecoilControl",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AimDrills",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "TroubleShooting",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Surgery",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "CovertMovement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Search",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "MagDrills",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Sniping",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "ProneMovement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "FieldMedicine",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "FirstAid",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "LightVests",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HeavyVests",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "WeaponModding",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AdvancedModding",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "NightOps",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "SilentOps",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Lockpicking",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "WeaponTreatment",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Freetrading",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Auctions",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Cleanoperations",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Barter",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Shadowconnections",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Taskperformance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Crafting",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HideoutManagement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "BearAssaultoperations",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearAuthority",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearAksystems",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearHeavycaliber",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearRawpower",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }
                        ],
                        "Mastering": [],
                        "Points": 0
                    },
                    "Stats": {
                        "Eft": {
                            "Aggressor": null,
                            "CarriedQuestItems": [],
                            "DamageHistory": {
                                "BodyParts": [],
                                "LethalDamage": null,
                                "LethalDamagePart": "Head"
                            },
                            "DroppedItems": [],
                            "ExperienceBonusMult": 0,
                            "FoundInRaidItems": [],
                            "LastPlayerState": null,
                            "LastSessionDate": 0,
                            "OverallCounters": {
                                "Items": []
                            },
                            "SessionCounters": {
                                "Items": []
                            },
                            "SessionExperienceMult": 0,
                            "SurvivorClass": "Unknown",
                            "TotalInGameTime": 0,
                            "TotalSessionExperience": 0,
                            "Victims": []
                        }
                    },
                    "TradersInfo": {},
                    "UnlockedInfo": {
                        "unlockedProductionRecipe": []
                    },
                    "moneyTransferLimitData": {
                        "nextResetTime": 1717779074,
                        "remainingLimit": 1000000,
                        "totalLimit": 1000000,
                        "resetInterval": 86400
                    },
                    "WishList": [],
                    "_id": "__REPLACEME__",
                    "aid": "__REPLACEME__",
                    "savage": "__REPLACEME__"
                },
                "dialogues": {},
                "equipmentBuilds": {},
                "suits": [
                    "5cd946231388ce000d572fe3",
                    "5cd945d71388ce000a659dfb"
                ],
                "trader": {
                    "initialLoyaltyLevel": {
                        "54cb50c76803fa8b248b4571": 1,
                        "54cb57776803fa99248b456e": 1,
                        "579dc571d53a0658a154fbec": 1,
                        "58330581ace78e27b8b10cee": 1,
                        "5935c25fb3acc3127c3d8cd9": 1,
                        "5a7c2eca46aef81a7ca2145d": 1,
                        "5ac3b934156ae10c4430e83c": 1,
                        "5c0647fdd443bc2504c2d371": 1,
                        "638f541a29ffd1183d187f57": 1
                    },
                    "initialStanding": {
                        "default": 0
                        "54cb50c76803fa8b248b4571": 0.2,
                        "54cb57776803fa99248b456e": 0.2,
                        "579dc571d53a0658a154fbec": 0,
                        "58330581ace78e27b8b10cee": 0.2,
                        "5935c25fb3acc3127c3d8cd9": -0.2,
                        "5a7c2eca46aef81a7ca2145d": -0.2,
                        "5ac3b934156ae10c4430e83c": -0.2,
                        "5c0647fdd443bc2504c2d371": 0.2,
                        "638f541a29ffd1183d187f57": 0.01
                    },
                    "initialSalesSum": 0,
                    "jaegerUnlocked": false,
                    "lockedByDefaultOverride": [
                        "579dc571d53a0658a154fbec"
                    ]
                },
                "weaponbuilds": {}
            },
            "usec": {
                "character": {
                    "TaskConditionCounters": {},
                    "Bonuses": [{
                        "id": "64f5b9e5fa34f11b380756c0",
                        "templateId": "566abbc34bdc2d92178b4576",
                        "type": "StashSize"
                    }
                    ],
                    "Customization": {
                        "Body": "5cde95d97d6c8b647a3769b0",
                        "Feet": "5cde95ef7d6c8b04713c4f2d",
                        "Hands": "5cde95fa7d6c8b04737c2d13",
                        "Head": "__REPLACEME__"
                    },
                    "Encyclopedia": {
                        "5447a9cd4bdc2dbd208b4567": false,
                        "5448bd6b4bdc2dfc2f8b4569": false,
                        "5448c12b4bdc2d02308b456f": false,
                        "5448fee04bdc2dbc018b4567": false,
                        "5449016a4bdc2d6f028b456f": false,
                        "54491bb74bdc2d09088b4567": false,
                        "544a11ac4bdc2d470e8b456a": false,
                        "544a38634bdc2d58388b4568": false,
                        "544a5cde4bdc2d39388b456b": false,
                        "544fb25a4bdc2dfb738b4567": false,
                        "544fb3364bdc2d34748b456a": false,
                        "544fb37f4bdc2dee738b4567": false,
                        "54527a984bdc2d4e668b4567": false,
                        "557ffd194bdc2d28148b457f": false,
                        "55d355e64bdc2d962f8b4569": false,
                        "55d3632e4bdc2d972f8b4569": false,
                        "55d44fd14bdc2d962f8b456e": false,
                        "55d459824bdc2d892f8b4573": false,
                        "55d4887d4bdc2d962f8b4570": false,
                        "55d4ae6c4bdc2d8b2f8b456e": false,
                        "55d4af3a4bdc2d972f8b456f": false,
                        "55d4b9964bdc2d1d4e8b456e": false,
                        "55d5f46a4bdc2d1b198b4567": false,
                        "55d7217a4bdc2d86028b456d": false,
                        "5645bcc04bdc2d363b8b4572": false,
                        "5648a7494bdc2d9d488b4583": false,
                        "5649ad3f4bdc2df8348b4585": false,
                        "5649be884bdc2d79388b4577": false,
                        "564ca99c4bdc2d16268b4589": false,
                        "566abbc34bdc2d92178b4576": false,
                        "56d59856d2720bd8418b456a": false,
                        "56d59948d2720bb7418b4582": false,
                        "56d59d3ad2720bdb418b4577": false,
                        "56d5a1f7d2720bb3418b456a": false,
                        "56d5a2bbd2720bb8418b456a": true,
                        "56d5a407d2720bb3418b456b": true,
                        "56d5a661d2720bd8418b456b": false,
                        "56d5a77ed2720b90418b4568": false,
                        "56dfef82d2720bbd668b4567": true,
                        "56ea8d2fd2720b7c698b4570": false,
                        "572b7fa524597762b747ce82": false,
                        "57347d7224597744596b4e72": false,
                        "57347da92459774491567cf5": false,
                        "573718ba2459775a75491131": false,
                        "5751a25924597722c463c472": false,
                        "5755356824597772cb798962": false,
                        "5755383e24597772cb798966": false,
                        "57dc2fa62459775949412633": false,
                        "57dc324a24597759501edc20": true,
                        "57dc32dc245977596d4ef3d3": false,
                        "57dc334d245977597164366f": true,
                        "57dc347d245977596754e7a1": false,
                        "58864a4f2459770fcc257101": false,
                        "58d3db5386f77426186285a0": false,
                        "590c5f0d86f77413997acfab": false,
                        "590c661e86f7741e566b646a": false,
                        "5926bb2186f7744b1c6c6e60": false,
                        "5926c0df86f77462f647f764": false,
                        "5926c32286f774616e42de99": false,
                        "5926c36d86f77467a92a8629": false,
                        "5926c3b286f774640d189b6b": false,
                        "5926d2be86f774134d668e4e": false,
                        "5926d3c686f77410de68ebc8": false,
                        "5926e16e86f7742f5a0f7ecb": false,
                        "59d36a0086f7747e673f3946": true,
                        "5a0c27731526d80618476ac4": false,
                        "5aa2a7e8e5b5b00016327c16": false,
                        "5ab8f39486f7745cd93a1cca": false,
                        "5ae30bad5acfc400185c2dc4": false,
                        "5ae30db85acfc408fb139a05": false,
                        "5ae30e795acfc408fb139a0b": false,
                        "5b44c8ea86f7742d1627baf1": false,
                        "5c0e9f2c86f77432297fe0a3": false,
                        "5cadc190ae921500103bb3b6": false,
                        "5cadc1c6ae9215000f2775a4": false,
                        "5cadc2e0ae9215051e1c21e7": false,
                        "5cadc390ae921500126a77f1": false,
                        "5cadc431ae921500113bb8d5": false,
                        "5cadc55cae921500103bb3be": false,
                        "5cadd919ae921500126a77f3": false,
                        "5cadd940ae9215051e1c2316": false,
                        "5d1b371186f774253763a656": false,
                        "5d2f213448f0355009199284": false,
                        "5d403f9186f7743cac3f229b": false,
                        "5e2af47786f7746d404f3aaa": false,
                        "5e2af4a786f7746d3f3c3400": false,
                        "5e4d34ca86f774264f758330": false,
                        "5e831507ea0a7c419c2f9bd9": false,
                        "5e9dcf5986f7746c417435b3": false
                    },
                    "Health": {
                        "BodyParts": {
                            "Chest": {
                                "Health": {
                                    "Current": 85,
                                    "Maximum": 85
                                }
                            },
                            "Head": {
                                "Health": {
                                    "Current": 35,
                                    "Maximum": 35
                                }
                            },
                            "LeftArm": {
                                "Health": {
                                    "Current": 60,
                                    "Maximum": 60
                                }
                            },
                            "LeftLeg": {
                                "Health": {
                                    "Current": 65,
                                    "Maximum": 65
                                }
                            },
                            "RightArm": {
                                "Health": {
                                    "Current": 60,
                                    "Maximum": 60
                                }
                            },
                            "RightLeg": {
                                "Health": {
                                    "Current": 65,
                                    "Maximum": 65
                                }
                            },
                            "Stomach": {
                                "Health": {
                                    "Current": 70,
                                    "Maximum": 70
                                }
                            }
                        },
                        "Energy": {
                            "Current": 100,
                            "Maximum": 100
                        },
                        "Hydration": {
                            "Current": 100,
                            "Maximum": 100
                        },
                        "Temperature": {
                            "Current": 36.6,
                            "Maximum": 40
                        },
                        "UpdateTime": 1736326673
                    },
                    "Hideout": {
                        "Areas": [
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 2,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 3
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 0
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 1
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 2
                            },
                            {
                                "active": false,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    },
                                    {
                                        "locationIndex": 5
                                    },
                                    {
                                        "locationIndex": 6
                                    },
                                    {
                                        "locationIndex": 7
                                    }
                                ],
                                "type": 4
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 5
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    }
                                ],
                                "type": 6
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 7
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 8
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 9
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 10
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 11
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 12
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 13
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 14
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 15
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 16
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": false,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    }
                                ],
                                "type": 17
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 18
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 19
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    },
                                    {
                                        "locationIndex": 5
                                    },
                                    {
                                        "locationIndex": 6
                                    },
                                    {
                                        "locationIndex": 7
                                    },
                                    {
                                        "locationIndex": 8
                                    },
                                    {
                                        "locationIndex": 9
                                    },
                                    {
                                        "locationIndex": 10
                                    },
                                    {
                                        "locationIndex": 11
                                    },
                                    {
                                        "locationIndex": 12
                                    },
                                    {
                                        "locationIndex": 13
                                    },
                                    {
                                        "locationIndex": 14
                                    },
                                    {
                                        "locationIndex": 15
                                    },
                                    {
                                        "locationIndex": 16
                                    },
                                    {
                                        "locationIndex": 17
                                    },
                                    {
                                        "locationIndex": 18
                                    },
                                    {
                                        "locationIndex": 19
                                    },
                                    {
                                        "locationIndex": 20
                                    },
                                    {
                                        "locationIndex": 21
                                    },
                                    {
                                        "locationIndex": 22
                                    },
                                    {
                                        "locationIndex": 23
                                    },
                                    {
                                        "locationIndex": 24
                                    },
                                    {
                                        "locationIndex": 25
                                    },
                                    {
                                        "locationIndex": 26
                                    },
                                    {
                                        "locationIndex": 27
                                    },
                                    {
                                        "locationIndex": 28
                                    },
                                    {
                                        "locationIndex": 29
                                    },
                                    {
                                        "locationIndex": 30
                                    },
                                    {
                                        "locationIndex": 31
                                    },
                                    {
                                        "locationIndex": 32
                                    },
                                    {
                                        "locationIndex": 33
                                    },
                                    {
                                        "locationIndex": 34
                                    },
                                    {
                                        "locationIndex": 35
                                    },
                                    {
                                        "locationIndex": 36
                                    },
                                    {
                                        "locationIndex": 37
                                    },
                                    {
                                        "locationIndex": 38
                                    },
                                    {
                                        "locationIndex": 39
                                    },
                                    {
                                        "locationIndex": 40
                                    },
                                    {
                                        "locationIndex": 41
                                    },
                                    {
                                        "locationIndex": 42
                                    },
                                    {
                                        "locationIndex": 43
                                    },
                                    {
                                        "locationIndex": 44
                                    },
                                    {
                                        "locationIndex": 45
                                    },
                                    {
                                        "locationIndex": 46
                                    },
                                    {
                                        "locationIndex": 47
                                    },
                                    {
                                        "locationIndex": 48
                                    },
                                    {
                                        "locationIndex": 49
                                    }
                                ],
                                "type": 20
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 21
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 22
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 23
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 24
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 25
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 26
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    }
                                ],
                                "type": 27
                            }
                        ],
                        "Improvements": {},
                        "Production": {},
                        "HideoutCounters": null,
                        "Seed": 1988614673,
                        "sptUpdateLastRunTimestamp": 1736326677
                    },
                    "Info": {
                        "AccountType": 0,
                        "BannedState": false,
                        "BannedUntil": 0,
                        "Bans": [],
                        "Experience": 0,
                        "GameVersion": "standard",
                        "IsStreamerModeAvailable": false,
                        "LastTimePlayedAsSavage": 0,
                        "Level": 1,
                        "LowerNickname": "__REPLACEME__",
                        "MemberCategory": 0,
                        "isMigratedSkills": false,
                        "SelectedMemberCategory": 0,
                        "Nickname": "__REPLACEME__",
                        "NicknameChangeDate": 0,
                        "RegistrationDate": "__REPLACEME__",
                        "SavageLockTime": 0,
                        "Settings": {
                            "BotDifficulty": "easy",
                            "Experience": -1,
                            "Role": "assault"
                        },
                        "Side": "Usec",
                        "SquadInviteRestriction": false,
                        "HasCoopExtension": false,
                        "Voice": "__REPLACEME__",
                        "lockedMoveCommands": true
                    },
                    "InsuredItems": [],
                    "Inventory": {
                        "equipment": "745fcb25fc898c3040325627",
                        "fastPanel": {},
                        "hideoutAreaStashes": {},
                        "items": [
                            {
                                "_id": "745fcb25fc898c3040325627",
                                "_tpl": "55d7217a4bdc2d86028b456d"
                            },
                            {
                                "_id": "9cd4a2c4ef26d2f93108da8e",
                                "_tpl": "6401c7b213d9b818bf0e7dd7"
                            },
                            {
                                "_id": "944d91661e2352dc413aeddc",
                                "_tpl": "5857a8b324597729ab0a0e7d",
                                "parentId": "745fcb25fc898c3040325627",
                                "slotId": "SecuredContainer"
                            },
                            {
                                "_id": "52b06a8b20aaa54d5fab1ae4",
                                "_tpl": "627a4e6b255f7527fb05a0f6",
                                "parentId": "745fcb25fc898c3040325627",
                                "slotId": "Pockets"
                            },
                            {
                                "_id": "5fe49cdfa19cac3fa9054115",
                                "_tpl": "5811ce572459770cba1a34ea"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b8",
                                "_tpl": "5963866b86f7747bfa1c4462"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b7",
                                "_tpl": "5963866286f7747bf429b572"
                            },
                            {
                                "_id": "60dca3da42ad9b706b369aca",
                                "_tpl": "602543c13fee350cd564d032"
                            },
                            {
                                "_id": "5eaef0f48cc3a0dd9e2440bd",
                                "_tpl": "5448c1d04bdc2dff2f8b4569",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "20b5f7fd067518bc1adcf9f7",
                                "_tpl": "5448c1d04bdc2dff2f8b4569",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "f4846d988cb95874c711f200",
                                "_tpl": "5448c1d04bdc2dff2f8b4569",
                                "parentId": "ad60bd5f9e885988d790b0d3",
                                "slotId": "mod_magazine",
                                "upd": {
                                    "StackObjectsCount": 1
                                }
                            },
                            {
                                "_id": "cfc5a61abe70d89045543760",
                                "_tpl": "5448c1d04bdc2dff2f8b4569",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "f0fb76a063d8ac25d68a8fc7",
                                "_tpl": "5448c1d04bdc2dff2f8b4569",
                                "parentId": "276f29f275d5ae901465d378",
                                "slotId": "mod_magazine",
                                "upd": {
                                    "StackObjectsCount": 1
                                }
                            },
                            {
                                "_id": "35b7fd1ed3d250079da53099",
                                "_tpl": "5448c1d04bdc2dff2f8b4569",
                                "parentId": "02d087ea6099fa8b78d3d873",
                                "slotId": "mod_magazine",
                                "upd": {
                                    "StackObjectsCount": 1
                                }
                            },
                            {
                                "_id": "ad60bd5f9e885988d790b0d3",
                                "_tpl": "5c07c60e0db834002330051f",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "5c10fcb186f774533e5529ab",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 5,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "7be55e6be9779a9cf8c500fa",
                                "_tpl": "5c0e2ff6d174af02a1659d4a",
                                "parentId": "ad60bd5f9e885988d790b0d3",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "ef4228dd473b25e3ab1608f3",
                                "_tpl": "5c0e2f26d174af02a9625114",
                                "parentId": "ad60bd5f9e885988d790b0d3",
                                "slotId": "mod_reciever",
                                "upd": {}
                            },
                            {
                                "_id": "e216029c4968a2d8bbf58d7c",
                                "_tpl": "5c0e2f94d174af029f650d56",
                                "parentId": "ef4228dd473b25e3ab1608f3",
                                "slotId": "mod_barrel",
                                "upd": {}
                            },
                            {
                                "_id": "8e0375ef1b9f367119a527dc",
                                "_tpl": "5c0fafb6d174af02a96260ba",
                                "parentId": "e216029c4968a2d8bbf58d7c",
                                "slotId": "mod_muzzle",
                                "upd": {}
                            },
                            {
                                "_id": "6708e72e97bd6f100e864909",
                                "_tpl": "5ae30e795acfc408fb139a0b",
                                "parentId": "e216029c4968a2d8bbf58d7c",
                                "slotId": "mod_gas_block",
                                "upd": {}
                            },
                            {
                                "_id": "29801b5ff2d5080675b5cefb",
                                "_tpl": "5c0e2f5cd174af02a012cfc9",
                                "parentId": "ef4228dd473b25e3ab1608f3",
                                "slotId": "mod_handguard",
                                "upd": {}
                            },
                            {
                                "_id": "a892c09cfe3609316a2beeef",
                                "_tpl": "5c0faeddd174af02a962601f",
                                "parentId": "ad60bd5f9e885988d790b0d3",
                                "slotId": "mod_stock",
                                "upd": {}
                            },
                            {
                                "_id": "59312420b6234e25671854b0",
                                "_tpl": "5c0faf68d174af02a96260b8",
                                "parentId": "ad60bd5f9e885988d790b0d3",
                                "slotId": "mod_charge",
                                "upd": {}
                            },
                            {
                                "_id": "276f29f275d5ae901465d378",
                                "_tpl": "5c07c60e0db834002330051f",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "5c10fcb186f774533e5529ab",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 0,
                                    "y": 2,
                                    "r": "Vertical",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "54f358624f9dbdb431edf8ac",
                                "_tpl": "5c0e2ff6d174af02a1659d4a",
                                "parentId": "276f29f275d5ae901465d378",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "69e26439785f1d2eb745a537",
                                "_tpl": "5c0e2f26d174af02a9625114",
                                "parentId": "276f29f275d5ae901465d378",
                                "slotId": "mod_reciever",
                                "upd": {}
                            },
                            {
                                "_id": "eb266eb14782803dd705bea9",
                                "_tpl": "5c0e2f94d174af029f650d56",
                                "parentId": "69e26439785f1d2eb745a537",
                                "slotId": "mod_barrel",
                                "upd": {}
                            },
                            {
                                "_id": "990b5016c694ce92bbddcae9",
                                "_tpl": "5c0fafb6d174af02a96260ba",
                                "parentId": "eb266eb14782803dd705bea9",
                                "slotId": "mod_muzzle",
                                "upd": {}
                            },
                            {
                                "_id": "1f7605ef7bd0cdfbbf6bacf1",
                                "_tpl": "5ae30e795acfc408fb139a0b",
                                "parentId": "eb266eb14782803dd705bea9",
                                "slotId": "mod_gas_block",
                                "upd": {}
                            },
                            {
                                "_id": "21f5824afcb11c49e1359590",
                                "_tpl": "5c0e2f5cd174af02a012cfc9",
                                "parentId": "69e26439785f1d2eb745a537",
                                "slotId": "mod_handguard",
                                "upd": {}
                            },
                            {
                                "_id": "859983ccd27e16c4180da9ca",
                                "_tpl": "5c0faeddd174af02a962601f",
                                "parentId": "276f29f275d5ae901465d378",
                                "slotId": "mod_stock",
                                "upd": {}
                            },
                            {
                                "_id": "6a31e78386d370b2c108cad7",
                                "_tpl": "5c0faf68d174af02a96260b8",
                                "parentId": "276f29f275d5ae901465d378",
                                "slotId": "mod_charge",
                                "upd": {}
                            },
                            {
                                "_id": "02d087ea6099fa8b78d3d873",
                                "_tpl": "5c07c60e0db834002330051f",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "5c10fcb186f774533e5529ab",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 0,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0cfd22caff917f22dbdd2929",
                                "_tpl": "5c0e2ff6d174af02a1659d4a",
                                "parentId": "02d087ea6099fa8b78d3d873",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "447fc5bcbfb9ffd5617b8fec",
                                "_tpl": "5c0e2f26d174af02a9625114",
                                "parentId": "02d087ea6099fa8b78d3d873",
                                "slotId": "mod_reciever",
                                "upd": {}
                            },
                            {
                                "_id": "6558c0a0bfaa9feb4909edd3",
                                "_tpl": "5c0e2f94d174af029f650d56",
                                "parentId": "447fc5bcbfb9ffd5617b8fec",
                                "slotId": "mod_barrel",
                                "upd": {}
                            },
                            {
                                "_id": "f5b02a9723c4bdd0c00331a2",
                                "_tpl": "5c0fafb6d174af02a96260ba",
                                "parentId": "6558c0a0bfaa9feb4909edd3",
                                "slotId": "mod_muzzle",
                                "upd": {}
                            },
                            {
                                "_id": "bd8228adb633b60e6bf204b6",
                                "_tpl": "5ae30e795acfc408fb139a0b",
                                "parentId": "6558c0a0bfaa9feb4909edd3",
                                "slotId": "mod_gas_block",
                                "upd": {}
                            },
                            {
                                "_id": "3daf4eb03c09281cc65e5194",
                                "_tpl": "5c0e2f5cd174af02a012cfc9",
                                "parentId": "447fc5bcbfb9ffd5617b8fec",
                                "slotId": "mod_handguard",
                                "upd": {}
                            },
                            {
                                "_id": "93c00b45269b3332bf06f6be",
                                "_tpl": "5c0faeddd174af02a962601f",
                                "parentId": "02d087ea6099fa8b78d3d873",
                                "slotId": "mod_stock",
                                "upd": {}
                            },
                            {
                                "_id": "37fbe3a966f2d1bfcfd09309",
                                "_tpl": "5c0faf68d174af02a96260b8",
                                "parentId": "02d087ea6099fa8b78d3d873",
                                "slotId": "mod_charge",
                                "upd": {}
                            },
                            {
                                "_id": "95e42d636bb629117bbac1a9",
                                "_tpl": "55d5f46a4bdc2d1b198b4567",
                                "parentId": "69e26439785f1d2eb745a537",
                                "slotId": "mod_sight_rear",
                                "upd": {
                                    "StackObjectsCount": 1
                                }
                            },
                            {
                                "_id": "7495dd2ad813b6ab8da01eaa",
                                "_tpl": "55d5f46a4bdc2d1b198b4567",
                                "parentId": "ef4228dd473b25e3ab1608f3",
                                "slotId": "mod_sight_rear",
                                "upd": {
                                    "StackObjectsCount": 1
                                }
                            },
                            {
                                "_id": "11335cd05d7ea36499e71c45",
                                "_tpl": "55d5f46a4bdc2d1b198b4567",
                                "parentId": "447fc5bcbfb9ffd5617b8fec",
                                "slotId": "mod_sight_rear",
                                "upd": {
                                    "StackObjectsCount": 1
                                }
                            },
                            {
                                "_id": "fc50d590d28cc8460b61db01",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "20b5f7fd067518bc1adcf9f7",
                                "slotId": "cartridges",
                                "upd": {
                                    "StackObjectsCount": 20
                                },
                                "location": 0
                            },
                            {
                                "_id": "ed2c67b4126896f45634a635",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 60
                                },
                                "location": {
                                    "x": 3,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "4d3a54af6a24aafe8bf11785",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "35b7fd1ed3d250079da53099",
                                "slotId": "cartridges",
                                "upd": {
                                    "StackObjectsCount": 20
                                },
                                "location": 0
                            },
                            {
                                "_id": "66a33be2010019812904019d",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "f4846d988cb95874c711f200",
                                "slotId": "cartridges",
                                "location": 0,
                                "upd": {
                                    "StackObjectsCount": 20
                                }
                            },
                            {
                                "_id": "66a33e90010019812988213b",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "5eaef0f48cc3a0dd9e2440bd",
                                "slotId": "cartridges",
                                "location": 0,
                                "upd": {
                                    "StackObjectsCount": 20
                                }
                            },
                            {
                                "_id": "66a33e9001001981294ec356",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "cfc5a61abe70d89045543760",
                                "slotId": "cartridges",
                                "location": 0,
                                "upd": {
                                    "StackObjectsCount": 20
                                }
                            },
                            {
                                "_id": "66a33e9101001981290f8ecf",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "f0fb76a063d8ac25d68a8fc7",
                                "slotId": "cartridges",
                                "location": 0,
                                "upd": {
                                    "StackObjectsCount": 20
                                }
                            },
                            {
                                "_id": "9f876c016d03641bbb0c5905",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 60
                                },
                                "location": {
                                    "x": 3,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "077e4c516fe6678c5ce794d9",
                                "_tpl": "59e6918f86f7746c9f75e849",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 60
                                },
                                "location": {
                                    "x": 3,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "9061318b50f9370d3873523f",
                                "_tpl": "5aa7d03ae5b5b00016327db5",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "307333399f6384872fa171b9",
                                "_tpl": "654a90aff4f81a421b0a7c86",
                                "parentId": "9061318b50f9370d3873523f",
                                "slotId": "helmet_top",
                                "upd": {}
                            },
                            {
                                "_id": "d4e2e0062ba6d19d1dc3df54",
                                "_tpl": "654a91068e1ce698150fd1e2",
                                "parentId": "9061318b50f9370d3873523f",
                                "slotId": "helmet_back",
                                "upd": {}
                            },
                            {
                                "_id": "ab855e774b6900447ad8883f",
                                "_tpl": "654a9189bcc67a392b056c79",
                                "parentId": "9061318b50f9370d3873523f",
                                "slotId": "helmet_ears",
                                "upd": {}
                            },
                            {
                                "_id": "b5fbf53536817b8431716154",
                                "_tpl": "5aa7d03ae5b5b00016327db5",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "9a6063f920425294df8e0a43",
                                "_tpl": "654a90aff4f81a421b0a7c86",
                                "parentId": "b5fbf53536817b8431716154",
                                "slotId": "helmet_top",
                                "upd": {}
                            },
                            {
                                "_id": "56c5b19cd8043eb997a4dff7",
                                "_tpl": "654a91068e1ce698150fd1e2",
                                "parentId": "b5fbf53536817b8431716154",
                                "slotId": "helmet_back",
                                "upd": {}
                            },
                            {
                                "_id": "df22a3b3860efb5e131e3c27",
                                "_tpl": "654a9189bcc67a392b056c79",
                                "parentId": "b5fbf53536817b8431716154",
                                "slotId": "helmet_ears",
                                "upd": {}
                            },
                            {
                                "_id": "67599a7cdaf20dfbc5d91fad",
                                "_tpl": "5aa7d03ae5b5b00016327db5",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 8,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "8bf95af1515fe96085ab93cb",
                                "_tpl": "654a90aff4f81a421b0a7c86",
                                "parentId": "67599a7cdaf20dfbc5d91fad",
                                "slotId": "helmet_top",
                                "upd": {}
                            },
                            {
                                "_id": "52ec74406611235dfa9e2d6d",
                                "_tpl": "654a91068e1ce698150fd1e2",
                                "parentId": "67599a7cdaf20dfbc5d91fad",
                                "slotId": "helmet_back",
                                "upd": {}
                            },
                            {
                                "_id": "431ef36a3679fa7be04c08f2",
                                "_tpl": "654a9189bcc67a392b056c79",
                                "parentId": "67599a7cdaf20dfbc5d91fad",
                                "slotId": "helmet_ears",
                                "upd": {}
                            },
                            {
                                "_id": "645b021f37e3da6c19689735",
                                "_tpl": "5755356824597772cb798962",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 5,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "217a64f69456afb91735840e",
                                "_tpl": "5755356824597772cb798962",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 5,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "b226bdb68d660f2d74df1479",
                                "_tpl": "5755356824597772cb798962",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 6,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "2bef5d0d778998558c7a32f3",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "cb41a9660464039261d33bef",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 7,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "721a1c0af14826ddd2157ffa",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 7,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "5d1542b9371e4cafc4845851",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "247876d800ef7e11cf9a8652",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "80089de00a7eb9dcb2259ab8",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "c04c9be8cd0241bec3d7a9e2",
                                "_tpl": "64be7095047e826eae02b0c1",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0c0590fca6fc491c8ca57be7",
                                "_tpl": "64be7095047e826eae02b0c1",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 8,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "49fd1a1a68aa5f5df41f78f3",
                                "_tpl": "6034d0230ca681766b6a0fb5",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 2,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "543e1be513a056fb302a28d4",
                                "_tpl": "5755356824597772cb798962",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "b7959daa68dd627ea4f92f17",
                                "_tpl": "5448fee04bdc2dbc018b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 8,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "5d240932f6223987da18c0f7",
                                "_tpl": "544fb37f4bdc2dee738b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "71df5d21decb5f019e392f50",
                                "_tpl": "544fb37f4bdc2dee738b4567",
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 7,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "e8719e59bc36ae54d68230b1",
                                "_tpl": "590c5f0d86f77413997acfab",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe49cdfa19cac3fa9054115",
                                "slotId": "hideout",
                                "location": {
                                    "x": 9,
                                    "y": 7,
                                    "r": 0,
                                    "rotation": false
                                }
                            }
                        ],
                        "questRaidItems": "5fe4977574f15b4ad31b66b7",
                        "questStashItems": "5fe4977574f15b4ad31b66b8",
                        "sortingTable": "60dca3da42ad9b706b369aca",
                        "stash": "5fe49cdfa19cac3fa9054115"
                    },
                    "Notes": {
                        "Notes": []
                    },
                    "Quests": [],
                    "RagfairInfo": {
                        "isRatingGrowing": true,
                        "offers": [],
                        "rating": 0.2
                    },
                    "Skills": {
                        "Common": [{
                            "Id": "BotReload",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "BotSound",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Endurance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Strength",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Vitality",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Health",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "StressResistance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Metabolism",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Immunity",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Perception",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Intellect",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Attention",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Charisma",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Memory",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Pistol",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Revolver",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "SMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Assault",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Shotgun",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Sniper",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "LMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Launcher",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AttachedLauncher",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Throwing",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Melee",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "DMR",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "RecoilControl",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AimDrills",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "TroubleShooting",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Surgery",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "CovertMovement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Search",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "MagDrills",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Sniping",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "ProneMovement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "FieldMedicine",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "FirstAid",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "LightVests",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HeavyVests",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "WeaponModding",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AdvancedModding",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "NightOps",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "SilentOps",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Lockpicking",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "WeaponTreatment",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Freetrading",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Auctions",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Cleanoperations",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Barter",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Shadowconnections",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Taskperformance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Crafting",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HideoutManagement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "BearAssaultoperations",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearAuthority",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearAksystems",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearHeavycaliber",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearRawpower",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }
                        ],
                        "Mastering": [],
                        "Points": 0
                    },
                    "Stats": {
                        "Eft": {
                            "Aggressor": null,
                            "CarriedQuestItems": [],
                            "DamageHistory": {
                                "BodyParts": [],
                                "LethalDamage": null,
                                "LethalDamagePart": "Head"
                            },
                            "DroppedItems": [],
                            "ExperienceBonusMult": 0,
                            "FoundInRaidItems": [],
                            "LastPlayerState": null,
                            "LastSessionDate": 0,
                            "OverallCounters": {
                                "Items": []
                            },
                            "SessionCounters": null,
                            "SessionExperienceMult": 0,
                            "SurvivorClass": "Unknown",
                            "TotalInGameTime": 0,
                            "TotalSessionExperience": 0,
                            "Victims": []
                        }
                    },
                    "TradersInfo": {},
                    "UnlockedInfo": {
                        "unlockedProductionRecipe": []
                    },
                    "moneyTransferLimitData": {
                        "nextResetTime": 1717779074,
                        "remainingLimit": 1000000,
                        "totalLimit": 1000000,
                        "resetInterval": 86400
                    },
                    "WishList": [],
                    "_id": "__REPLACEME__",
                    "aid": "__REPLACEME__",
                    "savage": "__REPLACEME__"
                },
                "dialogues": {},
                "equipmentBuilds": {},
                "suits": [
                    "5cde9ec17d6c8b04723cf479",
                    "5cde9e957d6c8b0474535da7"
                ],
                "trader": {
                    "initialLoyaltyLevel": {
                        "54cb50c76803fa8b248b4571": 1,
                        "54cb57776803fa99248b456e": 1,
                        "579dc571d53a0658a154fbec": 1,
                        "58330581ace78e27b8b10cee": 1,
                        "5935c25fb3acc3127c3d8cd9": 1,
                        "5a7c2eca46aef81a7ca2145d": 1,
                        "5ac3b934156ae10c4430e83c": 1,
                        "5c0647fdd443bc2504c2d371": 1,
                        "638f541a29ffd1183d187f57": 1
                    },
                    "initialStanding": {
                        "default": 0
                        "54cb50c76803fa8b248b4571": -0.2,
                        "54cb57776803fa99248b456e": -0.2,
                        "579dc571d53a0658a154fbec": 0,
                        "58330581ace78e27b8b10cee": 0.2,
                        "5935c25fb3acc3127c3d8cd9": 0.2,
                        "5a7c2eca46aef81a7ca2145d": 0.2,
                        "5ac3b934156ae10c4430e83c": 0.2,
                        "5c0647fdd443bc2504c2d371": -0.2,
                        "638f541a29ffd1183d187f57": 0.01
                    },
                    "initialSalesSum": 0,
                    "jaegerUnlocked": false,
                    "lockedByDefaultOverride": [
                        "579dc571d53a0658a154fbec"
                    ]
                },
                "weaponbuilds": {}
            }
        }
        this.logger.logWithColor(`[Choice Bound] [Alligence = Power] enabled`, LogTextColor.RED);
    }
}