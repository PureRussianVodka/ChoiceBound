/* eslint-disable @typescript-eslint/naming-convention */

/*
 * author: PureRussianVodka,
 * Version: 1.0.0
 * Compatible with: SPT 3.9.4
 * Date: 07/28/2024
 */

import { DependencyContainer } from "tsyringe";
import { ILogger } from "@spt/models/spt/utils/ILogger";
import { DatabaseServer } from "@spt/servers/DatabaseServer";
import { LogTextColor } from "@spt/models/spt/logging/LogTextColor";
import { LogBackgroundColor } from "@spt/models/spt/logging/LogBackgroundColor";

export class Storage
{
    private logger: ILogger;
    public storage_profile(container: DependencyContainer):void
    {
        this.logger = container.resolve<ILogger>("WinstonLogger");
        const profiles = container.resolve<DatabaseServer>("DatabaseServer").getTables().templates.profiles;

    //Logic for Storage = Power

        profiles["Storage = Power"] =
        {
            "descriptionLocaleKey": "Storage",
            "bear": {
                "character": {
                    "TaskConditionCounters": {},
                    "Bonuses": [{
                        "id": "64f5b9e5fa34f11b380756c0",
                        "templateId": "566abbc34bdc2d92178b4576",
                        "type": "StashSize"
                    }
                    ],
                    "Customization": {
                        "Body": "5cc0858d14c02e000c6bea66",
                        "Feet": "5cc085bb14c02e000e67a5c5",
                        "Hands": "5cc0876314c02e000c6bea6b",
                        "Head": "__REPLACEME__"
                    },
                    "Encyclopedia": {
                        "5447a9cd4bdc2dbd208b4567": false,
                        "5448bd6b4bdc2dfc2f8b4569": false,
                        "5448c12b4bdc2d02308b456f": false,
                        "5448fee04bdc2dbc018b4567": false,
                        "5449016a4bdc2d6f028b456f": false,
                        "54491bb74bdc2d09088b4567": false,
                        "544a11ac4bdc2d470e8b456a": false,
                        "544a38634bdc2d58388b4568": false,
                        "544a5cde4bdc2d39388b456b": false,
                        "544fb25a4bdc2dfb738b4567": false,
                        "544fb3364bdc2d34748b456a": false,
                        "544fb37f4bdc2dee738b4567": false,
                        "54527a984bdc2d4e668b4567": false,
                        "557ffd194bdc2d28148b457f": false,
                        "55d355e64bdc2d962f8b4569": false,
                        "55d3632e4bdc2d972f8b4569": false,
                        "55d44fd14bdc2d962f8b456e": false,
                        "55d459824bdc2d892f8b4573": false,
                        "55d4887d4bdc2d962f8b4570": false,
                        "55d4ae6c4bdc2d8b2f8b456e": false,
                        "55d4af3a4bdc2d972f8b456f": false,
                        "55d4b9964bdc2d1d4e8b456e": false,
                        "55d5f46a4bdc2d1b198b4567": false,
                        "55d7217a4bdc2d86028b456d": false,
                        "5645bcc04bdc2d363b8b4572": false,
                        "5648a7494bdc2d9d488b4583": false,
                        "5649ad3f4bdc2df8348b4585": false,
                        "5649be884bdc2d79388b4577": false,
                        "564ca99c4bdc2d16268b4589": false,
                        "566abbc34bdc2d92178b4576": false,
                        "56d59856d2720bd8418b456a": false,
                        "56d59948d2720bb7418b4582": false,
                        "56d59d3ad2720bdb418b4577": false,
                        "56d5a1f7d2720bb3418b456a": false,
                        "56d5a2bbd2720bb8418b456a": true,
                        "56d5a407d2720bb3418b456b": true,
                        "56d5a661d2720bd8418b456b": false,
                        "56d5a77ed2720b90418b4568": false,
                        "56dfef82d2720bbd668b4567": true,
                        "56ea8d2fd2720b7c698b4570": false,
                        "572b7fa524597762b747ce82": false,
                        "57347d7224597744596b4e72": false,
                        "57347da92459774491567cf5": false,
                        "573718ba2459775a75491131": false,
                        "5751a25924597722c463c472": false,
                        "5755356824597772cb798962": false,
                        "5755383e24597772cb798966": false,
                        "57dc2fa62459775949412633": false,
                        "57dc324a24597759501edc20": true,
                        "57dc32dc245977596d4ef3d3": false,
                        "57dc334d245977597164366f": true,
                        "57dc347d245977596754e7a1": false,
                        "58864a4f2459770fcc257101": false,
                        "58d3db5386f77426186285a0": false,
                        "590c5f0d86f77413997acfab": false,
                        "590c661e86f7741e566b646a": false,
                        "5926bb2186f7744b1c6c6e60": false,
                        "5926c0df86f77462f647f764": false,
                        "5926c32286f774616e42de99": false,
                        "5926c36d86f77467a92a8629": false,
                        "5926c3b286f774640d189b6b": false,
                        "5926d2be86f774134d668e4e": false,
                        "5926d3c686f77410de68ebc8": false,
                        "5926e16e86f7742f5a0f7ecb": false,
                        "59d36a0086f7747e673f3946": true,
                        "5a0c27731526d80618476ac4": false,
                        "5aa2a7e8e5b5b00016327c16": false,
                        "5ab8f39486f7745cd93a1cca": false,
                        "5ae30bad5acfc400185c2dc4": false,
                        "5ae30db85acfc408fb139a05": false,
                        "5ae30e795acfc408fb139a0b": false,
                        "5b44c8ea86f7742d1627baf1": false,
                        "5c0e9f2c86f77432297fe0a3": false,
                        "5cadc190ae921500103bb3b6": false,
                        "5cadc1c6ae9215000f2775a4": false,
                        "5cadc2e0ae9215051e1c21e7": false,
                        "5cadc390ae921500126a77f1": false,
                        "5cadc431ae921500113bb8d5": false,
                        "5cadc55cae921500103bb3be": false,
                        "5cadd919ae921500126a77f3": false,
                        "5cadd940ae9215051e1c2316": false,
                        "5d1b371186f774253763a656": false,
                        "5d2f213448f0355009199284": false,
                        "5d403f9186f7743cac3f229b": false,
                        "5e2af47786f7746d404f3aaa": false,
                        "5e2af4a786f7746d3f3c3400": false,
                        "5e4d34ca86f774264f758330": false,
                        "5e831507ea0a7c419c2f9bd9": false,
                        "5e9dcf5986f7746c417435b3": false
                    },
                    "Health": {
                        "BodyParts": {
                            "Chest": {
                                "Health": {
                                    "Current": 85,
                                    "Maximum": 85
                                }
                            },
                            "Head": {
                                "Health": {
                                    "Current": 35,
                                    "Maximum": 35
                                }
                            },
                            "LeftArm": {
                                "Health": {
                                    "Current": 60,
                                    "Maximum": 60
                                }
                            },
                            "LeftLeg": {
                                "Health": {
                                    "Current": 65,
                                    "Maximum": 65
                                }
                            },
                            "RightArm": {
                                "Health": {
                                    "Current": 60,
                                    "Maximum": 60
                                }
                            },
                            "RightLeg": {
                                "Health": {
                                    "Current": 65,
                                    "Maximum": 65
                                }
                            },
                            "Stomach": {
                                "Health": {
                                    "Current": 70,
                                    "Maximum": 70
                                }
                            }
                        },
                        "Energy": {
                            "Current": 100,
                            "Maximum": 100
                        },
                        "Hydration": {
                            "Current": 100,
                            "Maximum": 100
                        },
                        "Temperature": {
                            "Current": 36.6,
                            "Maximum": 40
                        },
                        "UpdateTime": 1736326673
                    },
                    "Hideout": {
                        "Areas": [
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 4,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 3
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 0
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 1
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 2
                            },
                            {
                                "active": false,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    },
                                    {
                                        "locationIndex": 5
                                    },
                                    {
                                        "locationIndex": 6
                                    },
                                    {
                                        "locationIndex": 7
                                    }
                                ],
                                "type": 4
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 5
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    }
                                ],
                                "type": 6
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 7
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 8
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 9
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 10
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 11
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 12
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 13
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 14
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 15
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 16
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": false,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    }
                                ],
                                "type": 17
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 18
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 19
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    },
                                    {
                                        "locationIndex": 5
                                    },
                                    {
                                        "locationIndex": 6
                                    },
                                    {
                                        "locationIndex": 7
                                    },
                                    {
                                        "locationIndex": 8
                                    },
                                    {
                                        "locationIndex": 9
                                    },
                                    {
                                        "locationIndex": 10
                                    },
                                    {
                                        "locationIndex": 11
                                    },
                                    {
                                        "locationIndex": 12
                                    },
                                    {
                                        "locationIndex": 13
                                    },
                                    {
                                        "locationIndex": 14
                                    },
                                    {
                                        "locationIndex": 15
                                    },
                                    {
                                        "locationIndex": 16
                                    },
                                    {
                                        "locationIndex": 17
                                    },
                                    {
                                        "locationIndex": 18
                                    },
                                    {
                                        "locationIndex": 19
                                    },
                                    {
                                        "locationIndex": 20
                                    },
                                    {
                                        "locationIndex": 21
                                    },
                                    {
                                        "locationIndex": 22
                                    },
                                    {
                                        "locationIndex": 23
                                    },
                                    {
                                        "locationIndex": 24
                                    },
                                    {
                                        "locationIndex": 25
                                    },
                                    {
                                        "locationIndex": 26
                                    },
                                    {
                                        "locationIndex": 27
                                    },
                                    {
                                        "locationIndex": 28
                                    },
                                    {
                                        "locationIndex": 29
                                    },
                                    {
                                        "locationIndex": 30
                                    },
                                    {
                                        "locationIndex": 31
                                    },
                                    {
                                        "locationIndex": 32
                                    },
                                    {
                                        "locationIndex": 33
                                    },
                                    {
                                        "locationIndex": 34
                                    },
                                    {
                                        "locationIndex": 35
                                    },
                                    {
                                        "locationIndex": 36
                                    },
                                    {
                                        "locationIndex": 37
                                    },
                                    {
                                        "locationIndex": 38
                                    },
                                    {
                                        "locationIndex": 39
                                    },
                                    {
                                        "locationIndex": 40
                                    },
                                    {
                                        "locationIndex": 41
                                    },
                                    {
                                        "locationIndex": 42
                                    },
                                    {
                                        "locationIndex": 43
                                    },
                                    {
                                        "locationIndex": 44
                                    },
                                    {
                                        "locationIndex": 45
                                    },
                                    {
                                        "locationIndex": 46
                                    },
                                    {
                                        "locationIndex": 47
                                    },
                                    {
                                        "locationIndex": 48
                                    },
                                    {
                                        "locationIndex": 49
                                    }
                                ],
                                "type": 20
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 21
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 22
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 23
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 24
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 25
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 26
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    }
                                ],
                                "type": 27
                            }
                        ],
                        "Improvements": {},
                        "Production": {},
                        "HideoutCounters": null,
                        "Seed": 1988614673,
                        "sptUpdateLastRunTimestamp": 1736326677
                    },
                    "Info": {
                        "AccountType": 0,
                        "BannedState": false,
                        "BannedUntil": 0,
                        "Bans": [],
                        "Experience": 0,
                        "GameVersion": "standard",
                        "IsStreamerModeAvailable": false,
                        "LastTimePlayedAsSavage": 0,
                        "Level": 1,
                        "LowerNickname": "__REPLACEME__",
                        "MemberCategory": 0,
                        "isMigratedSkills": false,
                        "SelectedMemberCategory": 0,
                        "Nickname": "__REPLACEME__",
                        "NicknameChangeDate": 0,
                        "RegistrationDate": "__REPLACEME__",
                        "SavageLockTime": 0,
                        "Settings": {
                            "BotDifficulty": "easy",
                            "Experience": -1,
                            "Role": "assault"
                        },
                        "Side": "Bear",
                        "SquadInviteRestriction": false,
                        "HasCoopExtension": false,
                        "Voice": "__REPLACEME__",
                        "lockedMoveCommands": true
                    },
                    "InsuredItems": [],
                    "Inventory": {
                        "equipment": "c53e4630f4885bfd3cddc8c5",
                        "fastPanel": {},
                        "hideoutAreaStashes": {},
                        "items": [
                            {
                                "_id": "c53e4630f4885bfd3cddc8c5",
                                "_tpl": "55d7217a4bdc2d86028b456d"
                            },
                            {
                                "_id": "68ad54efe80be1221a8837c0",
                                "_tpl": "6401c7b213d9b818bf0e7dd7"
                            },
                            {
                                "_id": "2a16c39b8958a1708c73098f",
                                "_tpl": "544a11ac4bdc2d470e8b456a",
                                "parentId": "c53e4630f4885bfd3cddc8c5",
                                "slotId": "SecuredContainer"
                            },
                            {
                                "_id": "c3f1af931d0e5377797efa67",
                                "_tpl": "627a4e6b255f7527fb05a0f6",
                                "parentId": "c53e4630f4885bfd3cddc8c5",
                                "slotId": "Pockets"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b6",
                                "_tpl": "5811ce772459770e9e5f9532"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b8",
                                "_tpl": "5963866b86f7747bfa1c4462"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b7",
                                "_tpl": "5963866286f7747bf429b572"
                            },
                            {
                                "_id": "60dca3da42ad9b706b369aca",
                                "_tpl": "602543c13fee350cd564d032"
                            },
                            {
                                "_id": "f72a5eea10dd51cdff2426b4",
                                "_tpl": "56d59d3ad2720bdb418b4577",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "location": {
                                    "x": 2,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "fce1431d8a53b0affd4ef33a",
                                "_tpl": "58864a4f2459770fcc257101",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "location": {
                                    "x": 2,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "6973f3be1f471445de4d9724",
                                "_tpl": "58864a4f2459770fcc257101",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "location": {
                                    "x": 2,
                                    "y": 1,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "52392f34d3fe8cccc66dbc9d",
                                "_tpl": "58864a4f2459770fcc257101",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "location": {
                                    "x": 2,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "6c78b5483388b921ea0f97e7",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 0,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "1b22e2bfb298e7129a2308c0",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "6c78b5483388b921ea0f97e7",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "7e676ac39a5e3df88681a0f3",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "6c78b5483388b921ea0f97e7",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "49f0a4312241c6903839fce3",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "6c78b5483388b921ea0f97e7",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "dfade949b20b80d2c529500b",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 1,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "b119b18bad58f5a1cdda43b6",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "dfade949b20b80d2c529500b",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "4de3e17039bcd61f33bdfa5e",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "dfade949b20b80d2c529500b",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "86ad407c524a7e98e7d1b095",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "dfade949b20b80d2c529500b",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "8dbafe42141e42897a28a67d",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0c758b3fa94a0fc206db8314",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "8dbafe42141e42897a28a67d",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "a5b8d19808c3d86071f03f37",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "8dbafe42141e42897a28a67d",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "71fcea7acad3ff522162d0c1",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "8dbafe42141e42897a28a67d",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "54773ca6629cd42197918240",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "75e42ed3d44648c0aec084aa",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "54773ca6629cd42197918240",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "042d3209a52c96b064b3990e",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "54773ca6629cd42197918240",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "f1d69687355e20b4ee91bcd2",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "54773ca6629cd42197918240",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "3573c628906149c48aed18a2",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "ef04fe565245686b553e3bfd",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "3573c628906149c48aed18a2",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "0768fb16d4918c9eb2551c77",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "3573c628906149c48aed18a2",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "7be020b7746989c49d3f316b",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "3573c628906149c48aed18a2",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "4d26203f17c408612d8df85a",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 86,
                                        "MaxDurability": 87
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 0,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "3bbdac2324bc649997bf7764",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "4d26203f17c408612d8df85a",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "f5f1a47e144629b53463bcec",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "4d26203f17c408612d8df85a",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "8cf0ac4d5ee398aecb54ac3d",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "4d26203f17c408612d8df85a",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "f26ec99c41044b9c72c966d8",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 1,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "4a94396858be9d53da7ce380",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "f26ec99c41044b9c72c966d8",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "34ea96a65177f48cdfce9c50",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "f26ec99c41044b9c72c966d8",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "b2bc882890435995671a778d",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "f26ec99c41044b9c72c966d8",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "4d335b84ae8e536f196584df",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 0,
                                    "y": 1,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "7c26a1ad89d5464b34df9a58",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "4d335b84ae8e536f196584df",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "38b219265f11b2d8653e46f8",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "4d335b84ae8e536f196584df",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "5a2d1c9ec56e70d8f637de9d",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "4d335b84ae8e536f196584df",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "1e6a7f491c00bf1dd2654480",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 0,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "c999fb4b5ee77548bddbfa3f",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "1e6a7f491c00bf1dd2654480",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "8a7e1c73b0ef5abaa88bf667",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "1e6a7f491c00bf1dd2654480",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "666c428920ab9b4164dc7361",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "1e6a7f491c00bf1dd2654480",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "851de1688a25201b215b8641",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 99,
                                        "MaxDurability": 99
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 1,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "9e2a7b5d56ed1782243c1523",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "851de1688a25201b215b8641",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "af3207d96ff899d41f732c7f",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "851de1688a25201b215b8641",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "10fbf9a8d557c3c475849840",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "851de1688a25201b215b8641",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "f1d9e6d078800ea5a2c9fd5e",
                                "_tpl": "590c661e86f7741e566b646a",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "MedKit": {
                                        "HpResource": 220
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 4,
                                    "y": 2,
                                    "r": "Vertical",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "13b108a231a8dab6c71a6d53",
                                "_tpl": "590c661e86f7741e566b646a",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "MedKit": {
                                        "HpResource": 220
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 3,
                                    "y": 2,
                                    "r": "Vertical",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0b88337e1b48d2cf743234cf",
                                "_tpl": "590c657e86f77412b013051d",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "2ea8c2e71968f169cc9db885",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "6ac0524fe5445653a891a069",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "7702a0b9f37e1142583db0e8",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "4144e2a0ada29f73f2681d74",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "2a47e1d49ad53f38762434a9",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "bcdf50ce93c9a30eac9ec39f",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "83f5e352b7657ffeef7d3b6e",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "74acab023b32b8d91aa9a1aa",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "11f12b6086d736c367b9b82c",
                                "_tpl": "56e33634d2720bd8058b456b",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 6,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "881995c196bb9a01aa86a156",
                                "_tpl": "56e33634d2720bd8058b456b",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 7,
                                    "y": 0,
                                    "r": 1,
                                    "rotation": true
                                }
                            },
                            {
                                "_id": "848c5afa6a291240d28c62c0",
                                "_tpl": "56e33634d2720bd8058b456b",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 6,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "d7e2363d3b46878d373ea1f9",
                                "_tpl": "58864a4f2459770fcc257101",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 2,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "62d47895988d477532e2214f",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "bd2024f94830609ab55482fe",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "751a7af4186736e43c7ee928",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 1,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "ae3291566798c7ccdb39e02f",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 1,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "5c6a39b726eb75a718bd66b2",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "c9ca6621d09ec1653a2b51e3",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "7299e27a2ff61c69f47ad51a",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "cca77c07faffd61c58d2df3f",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "500866d97f1335bc212504a3",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 4,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "bba76a8b7fcac05ee1672f14",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 4,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "04370fc08895c0f7b4f53c7f",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "40ea95be0d3eddbe736b2113",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 5,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "7773f0cf0e03515dd8ee5042",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 5,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "48503ff6c2d86240728a52cf",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0516d9557b7a015b3ea21e84",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "39a91673da031fe35bf4d339",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "a0a93caedaf9f9d87958f7b5",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "d9ef7b5e8b9476d7071b35a6",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "e38943e9fedfda8148c9b67e",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 7,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "db28c8fb645e4c817573cecc",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 7,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "9ac2f433ece7acf5fe11fd60",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "2084016cd18485efebb94fc5",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "66a57348010019812987dc34",
                                "_tpl": "5449016a4bdc2d6f028b456f",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 9,
                                    "y": 10,
                                    "r": "Horizontal",
                                    "isSearched": true
                                },
                                "upd": {
                                    "StackObjectsCount": -2500000,
                                    "SpawnedInSession": false
                                }
                            },
                            {
                                "_id": "66a574b201001981294446c2",
                                "_tpl": "5449016a4bdc2d6f028b456f",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 8,
                                    "y": 10,
                                    "r": "Horizontal",
                                    "isSearched": true
                                },
                                "upd": {
                                    "StackObjectsCount": -2500000,
                                    "SpawnedInSession": false
                                }
                            },
                            {
                                "_id": "66a574b50100198129785edd",
                                "_tpl": "5449016a4bdc2d6f028b456f",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 7,
                                    "y": 10,
                                    "r": "Horizontal",
                                    "isSearched": true
                                },
                                "upd": {
                                    "StackObjectsCount": -2500000,
                                    "SpawnedInSession": false
                                }
                            },
                            {
                                "_id": "66a574bc0100198129c9a0ab",
                                "_tpl": "5449016a4bdc2d6f028b456f",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 6,
                                    "y": 10,
                                    "r": "Horizontal",
                                    "isSearched": true
                                },
                                "upd": {
                                    "StackObjectsCount": -2500000,
                                    "SpawnedInSession": false
                                }
                            }
                        ],
                        "questRaidItems": "5fe4977574f15b4ad31b66b7",
                        "questStashItems": "5fe4977574f15b4ad31b66b8",
                        "sortingTable": "60dca3da42ad9b706b369aca",
                        "stash": "5fe4977574f15b4ad31b66b6"
                    },
                    "Notes": {
                        "Notes": []
                    },
                    "Quests": [],
                    "RagfairInfo": {
                        "isRatingGrowing": true,
                        "offers": [],
                        "rating": 0.2
                    },
                    "Skills": {
                        "Common": [{
                            "Id": "BotReload",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "BotSound",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Endurance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Strength",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Vitality",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Health",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "StressResistance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Metabolism",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Immunity",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Perception",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Intellect",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Attention",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Charisma",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Memory",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Pistol",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Revolver",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "SMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Assault",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Shotgun",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Sniper",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "LMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Launcher",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AttachedLauncher",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Throwing",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Melee",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "DMR",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "RecoilControl",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AimDrills",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "TroubleShooting",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Surgery",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "CovertMovement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Search",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "MagDrills",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Sniping",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "ProneMovement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "FieldMedicine",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "FirstAid",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "LightVests",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HeavyVests",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "WeaponModding",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AdvancedModding",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "NightOps",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "SilentOps",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Lockpicking",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "WeaponTreatment",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Freetrading",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Auctions",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Cleanoperations",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Barter",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Shadowconnections",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Taskperformance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Crafting",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HideoutManagement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "BearAssaultoperations",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearAuthority",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearAksystems",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearHeavycaliber",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearRawpower",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }
                        ],
                        "Mastering": [],
                        "Points": 0
                    },
                    "Stats": {
                        "Eft": {
                            "Aggressor": null,
                            "CarriedQuestItems": [],
                            "DamageHistory": {
                                "BodyParts": [],
                                "LethalDamage": null,
                                "LethalDamagePart": "Head"
                            },
                            "DroppedItems": [],
                            "ExperienceBonusMult": 0,
                            "FoundInRaidItems": [],
                            "LastPlayerState": null,
                            "LastSessionDate": 0,
                            "OverallCounters": {
                                "Items": []
                            },
                            "SessionCounters": {
                                "Items": []
                            },
                            "SessionExperienceMult": 0,
                            "SurvivorClass": "Unknown",
                            "TotalInGameTime": 0,
                            "TotalSessionExperience": 0,
                            "Victims": []
                        }
                    },
                    "TradersInfo": {},
                    "UnlockedInfo": {
                        "unlockedProductionRecipe": []
                    },
                    "moneyTransferLimitData": {
                        "nextResetTime": 1717779074,
                        "remainingLimit": 1000000,
                        "totalLimit": 1000000,
                        "resetInterval": 86400
                    },
                    "WishList": [],
                    "_id": "__REPLACEME__",
                    "aid": "__REPLACEME__",
                    "savage": "__REPLACEME__"
                },
                "dialogues": {},
                "equipmentBuilds": {},
                "suits": [
                    "5cd946231388ce000d572fe3",
                    "5cd945d71388ce000a659dfb"
                ],
                "trader": {
                    "initialLoyaltyLevel": {
                        "54cb50c76803fa8b248b4571": 1,
                        "54cb57776803fa99248b456e": 1,
                        "579dc571d53a0658a154fbec": 1,
                        "58330581ace78e27b8b10cee": 1,
                        "5935c25fb3acc3127c3d8cd9": 1,
                        "5a7c2eca46aef81a7ca2145d": 1,
                        "5ac3b934156ae10c4430e83c": 1,
                        "5c0647fdd443bc2504c2d371": 1,
                        "638f541a29ffd1183d187f57": 1
                    },
                    "initialStanding": {
                        "default": 0.0,
                        "54cb50c76803fa8b248b4571": -0.3,
                        "54cb57776803fa99248b456e": -0.3,
                        "579dc571d53a0658a154fbec": -6,
                        "58330581ace78e27b8b10cee": -0.3,
                        "5935c25fb3acc3127c3d8cd9": -0.3,
                        "5a7c2eca46aef81a7ca2145d": -0.3,
                        "5ac3b934156ae10c4430e83c": -0.3,
                        "5c0647fdd443bc2504c2d371": -0.3,
                        "638f541a29ffd1183d187f57": 0.01
                    },
                    "initialSalesSum": 0,
                    "jaegerUnlocked": false,
                    "lockedByDefaultOverride": [
                        "579dc571d53a0658a154fbec"
                    ]
                },
                "weaponbuilds": {}
            },
            "usec": {
                "character": {
                    "TaskConditionCounters": {},
                    "Bonuses": [{
                        "id": "64f5b9e5fa34f11b380756c0",
                        "templateId": "566abbc34bdc2d92178b4576",
                        "type": "StashSize"
                    }
                    ],
                    "Customization": {
                        "Body": "5cde95d97d6c8b647a3769b0",
                        "Feet": "5cde95ef7d6c8b04713c4f2d",
                        "Hands": "5cde95fa7d6c8b04737c2d13",
                        "Head": "__REPLACEME__"
                    },
                    "Encyclopedia": {
                        "5447a9cd4bdc2dbd208b4567": false,
                        "5448bd6b4bdc2dfc2f8b4569": false,
                        "5448c12b4bdc2d02308b456f": false,
                        "5448fee04bdc2dbc018b4567": false,
                        "5449016a4bdc2d6f028b456f": false,
                        "54491bb74bdc2d09088b4567": false,
                        "544a11ac4bdc2d470e8b456a": false,
                        "544a38634bdc2d58388b4568": false,
                        "544a5cde4bdc2d39388b456b": false,
                        "544fb25a4bdc2dfb738b4567": false,
                        "544fb3364bdc2d34748b456a": false,
                        "544fb37f4bdc2dee738b4567": false,
                        "54527a984bdc2d4e668b4567": false,
                        "557ffd194bdc2d28148b457f": false,
                        "55d355e64bdc2d962f8b4569": false,
                        "55d3632e4bdc2d972f8b4569": false,
                        "55d44fd14bdc2d962f8b456e": false,
                        "55d459824bdc2d892f8b4573": false,
                        "55d4887d4bdc2d962f8b4570": false,
                        "55d4ae6c4bdc2d8b2f8b456e": false,
                        "55d4af3a4bdc2d972f8b456f": false,
                        "55d4b9964bdc2d1d4e8b456e": false,
                        "55d5f46a4bdc2d1b198b4567": false,
                        "55d7217a4bdc2d86028b456d": false,
                        "5645bcc04bdc2d363b8b4572": false,
                        "5648a7494bdc2d9d488b4583": false,
                        "5649ad3f4bdc2df8348b4585": false,
                        "5649be884bdc2d79388b4577": false,
                        "564ca99c4bdc2d16268b4589": false,
                        "566abbc34bdc2d92178b4576": false,
                        "56d59856d2720bd8418b456a": false,
                        "56d59948d2720bb7418b4582": false,
                        "56d59d3ad2720bdb418b4577": false,
                        "56d5a1f7d2720bb3418b456a": false,
                        "56d5a2bbd2720bb8418b456a": true,
                        "56d5a407d2720bb3418b456b": true,
                        "56d5a661d2720bd8418b456b": false,
                        "56d5a77ed2720b90418b4568": false,
                        "56dfef82d2720bbd668b4567": true,
                        "56ea8d2fd2720b7c698b4570": false,
                        "572b7fa524597762b747ce82": false,
                        "57347d7224597744596b4e72": false,
                        "57347da92459774491567cf5": false,
                        "573718ba2459775a75491131": false,
                        "5751a25924597722c463c472": false,
                        "5755356824597772cb798962": false,
                        "5755383e24597772cb798966": false,
                        "57dc2fa62459775949412633": false,
                        "57dc324a24597759501edc20": true,
                        "57dc32dc245977596d4ef3d3": false,
                        "57dc334d245977597164366f": true,
                        "57dc347d245977596754e7a1": false,
                        "58864a4f2459770fcc257101": false,
                        "58d3db5386f77426186285a0": false,
                        "590c5f0d86f77413997acfab": false,
                        "590c661e86f7741e566b646a": false,
                        "5926bb2186f7744b1c6c6e60": false,
                        "5926c0df86f77462f647f764": false,
                        "5926c32286f774616e42de99": false,
                        "5926c36d86f77467a92a8629": false,
                        "5926c3b286f774640d189b6b": false,
                        "5926d2be86f774134d668e4e": false,
                        "5926d3c686f77410de68ebc8": false,
                        "5926e16e86f7742f5a0f7ecb": false,
                        "59d36a0086f7747e673f3946": true,
                        "5a0c27731526d80618476ac4": false,
                        "5aa2a7e8e5b5b00016327c16": false,
                        "5ab8f39486f7745cd93a1cca": false,
                        "5ae30bad5acfc400185c2dc4": false,
                        "5ae30db85acfc408fb139a05": false,
                        "5ae30e795acfc408fb139a0b": false,
                        "5b44c8ea86f7742d1627baf1": false,
                        "5c0e9f2c86f77432297fe0a3": false,
                        "5cadc190ae921500103bb3b6": false,
                        "5cadc1c6ae9215000f2775a4": false,
                        "5cadc2e0ae9215051e1c21e7": false,
                        "5cadc390ae921500126a77f1": false,
                        "5cadc431ae921500113bb8d5": false,
                        "5cadc55cae921500103bb3be": false,
                        "5cadd919ae921500126a77f3": false,
                        "5cadd940ae9215051e1c2316": false,
                        "5d1b371186f774253763a656": false,
                        "5d2f213448f0355009199284": false,
                        "5d403f9186f7743cac3f229b": false,
                        "5e2af47786f7746d404f3aaa": false,
                        "5e2af4a786f7746d3f3c3400": false,
                        "5e4d34ca86f774264f758330": false,
                        "5e831507ea0a7c419c2f9bd9": false,
                        "5e9dcf5986f7746c417435b3": false
                    },
                    "Health": {
                        "BodyParts": {
                            "Chest": {
                                "Health": {
                                    "Current": 85,
                                    "Maximum": 85
                                }
                            },
                            "Head": {
                                "Health": {
                                    "Current": 35,
                                    "Maximum": 35
                                }
                            },
                            "LeftArm": {
                                "Health": {
                                    "Current": 60,
                                    "Maximum": 60
                                }
                            },
                            "LeftLeg": {
                                "Health": {
                                    "Current": 65,
                                    "Maximum": 65
                                }
                            },
                            "RightArm": {
                                "Health": {
                                    "Current": 60,
                                    "Maximum": 60
                                }
                            },
                            "RightLeg": {
                                "Health": {
                                    "Current": 65,
                                    "Maximum": 65
                                }
                            },
                            "Stomach": {
                                "Health": {
                                    "Current": 70,
                                    "Maximum": 70
                                }
                            }
                        },
                        "Energy": {
                            "Current": 100,
                            "Maximum": 100
                        },
                        "Hydration": {
                            "Current": 100,
                            "Maximum": 100
                        },
                        "Temperature": {
                            "Current": 36.6,
                            "Maximum": 40
                        },
                        "UpdateTime": 1736326673
                    },
                    "Hideout": {
                        "Areas": [
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 4,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 3
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 0
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 1
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 2
                            },
                            {
                                "active": false,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    },
                                    {
                                        "locationIndex": 5
                                    },
                                    {
                                        "locationIndex": 6
                                    },
                                    {
                                        "locationIndex": 7
                                    }
                                ],
                                "type": 4
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 5
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    }
                                ],
                                "type": 6
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 7
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 8
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 9
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 10
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 11
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 12
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 13
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 14
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 15
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 16
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": false,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    }
                                ],
                                "type": 17
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 18
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 19
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    },
                                    {
                                        "locationIndex": 1
                                    },
                                    {
                                        "locationIndex": 2
                                    },
                                    {
                                        "locationIndex": 3
                                    },
                                    {
                                        "locationIndex": 4
                                    },
                                    {
                                        "locationIndex": 5
                                    },
                                    {
                                        "locationIndex": 6
                                    },
                                    {
                                        "locationIndex": 7
                                    },
                                    {
                                        "locationIndex": 8
                                    },
                                    {
                                        "locationIndex": 9
                                    },
                                    {
                                        "locationIndex": 10
                                    },
                                    {
                                        "locationIndex": 11
                                    },
                                    {
                                        "locationIndex": 12
                                    },
                                    {
                                        "locationIndex": 13
                                    },
                                    {
                                        "locationIndex": 14
                                    },
                                    {
                                        "locationIndex": 15
                                    },
                                    {
                                        "locationIndex": 16
                                    },
                                    {
                                        "locationIndex": 17
                                    },
                                    {
                                        "locationIndex": 18
                                    },
                                    {
                                        "locationIndex": 19
                                    },
                                    {
                                        "locationIndex": 20
                                    },
                                    {
                                        "locationIndex": 21
                                    },
                                    {
                                        "locationIndex": 22
                                    },
                                    {
                                        "locationIndex": 23
                                    },
                                    {
                                        "locationIndex": 24
                                    },
                                    {
                                        "locationIndex": 25
                                    },
                                    {
                                        "locationIndex": 26
                                    },
                                    {
                                        "locationIndex": 27
                                    },
                                    {
                                        "locationIndex": 28
                                    },
                                    {
                                        "locationIndex": 29
                                    },
                                    {
                                        "locationIndex": 30
                                    },
                                    {
                                        "locationIndex": 31
                                    },
                                    {
                                        "locationIndex": 32
                                    },
                                    {
                                        "locationIndex": 33
                                    },
                                    {
                                        "locationIndex": 34
                                    },
                                    {
                                        "locationIndex": 35
                                    },
                                    {
                                        "locationIndex": 36
                                    },
                                    {
                                        "locationIndex": 37
                                    },
                                    {
                                        "locationIndex": 38
                                    },
                                    {
                                        "locationIndex": 39
                                    },
                                    {
                                        "locationIndex": 40
                                    },
                                    {
                                        "locationIndex": 41
                                    },
                                    {
                                        "locationIndex": 42
                                    },
                                    {
                                        "locationIndex": 43
                                    },
                                    {
                                        "locationIndex": 44
                                    },
                                    {
                                        "locationIndex": 45
                                    },
                                    {
                                        "locationIndex": 46
                                    },
                                    {
                                        "locationIndex": 47
                                    },
                                    {
                                        "locationIndex": 48
                                    },
                                    {
                                        "locationIndex": 49
                                    }
                                ],
                                "type": 20
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 21
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 22
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 23
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 24
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 25
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [],
                                "type": 26
                            },
                            {
                                "active": true,
                                "completeTime": 0,
                                "constructing": false,
                                "lastRecipe": "",
                                "level": 0,
                                "passiveBonusesEnabled": true,
                                "slots": [
                                    {
                                        "locationIndex": 0
                                    }
                                ],
                                "type": 27
                            }
                        ],
                        "Improvements": {},
                        "Production": {},
                        "HideoutCounters": null,
                        "Seed": 1988614673,
                        "sptUpdateLastRunTimestamp": 1736326677
                    },
                    "Info": {
                        "AccountType": 0,
                        "BannedState": false,
                        "BannedUntil": 0,
                        "Bans": [],
                        "Experience": 0,
                        "GameVersion": "standard",
                        "IsStreamerModeAvailable": false,
                        "LastTimePlayedAsSavage": 0,
                        "Level": 1,
                        "LowerNickname": "__REPLACEME__",
                        "MemberCategory": 0,
                        "isMigratedSkills": false,
                        "SelectedMemberCategory": 0,
                        "Nickname": "__REPLACEME__",
                        "NicknameChangeDate": 0,
                        "RegistrationDate": "__REPLACEME__",
                        "SavageLockTime": 0,
                        "Settings": {
                            "BotDifficulty": "easy",
                            "Experience": -1,
                            "Role": "assault"
                        },
                        "Side": "Usec",
                        "SquadInviteRestriction": false,
                        "HasCoopExtension": false,
                        "Voice": "__REPLACEME__",
                        "lockedMoveCommands": true
                    },
                    "InsuredItems": [],
                    "Inventory": {
                        "equipment": "c53e4630f4885bfd3cddc8c5",
                        "fastPanel": {},
                        "hideoutAreaStashes": {},
                        "items": [
                            {
                                "_id": "c53e4630f4885bfd3cddc8c5",
                                "_tpl": "55d7217a4bdc2d86028b456d"
                            },
                            {
                                "_id": "68ad54efe80be1221a8837c0",
                                "_tpl": "6401c7b213d9b818bf0e7dd7"
                            },
                            {
                                "_id": "2a16c39b8958a1708c73098f",
                                "_tpl": "544a11ac4bdc2d470e8b456a",
                                "parentId": "c53e4630f4885bfd3cddc8c5",
                                "slotId": "SecuredContainer"
                            },
                            {
                                "_id": "c3f1af931d0e5377797efa67",
                                "_tpl": "627a4e6b255f7527fb05a0f6",
                                "parentId": "c53e4630f4885bfd3cddc8c5",
                                "slotId": "Pockets"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b6",
                                "_tpl": "5811ce772459770e9e5f9532"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b8",
                                "_tpl": "5963866b86f7747bfa1c4462"
                            },
                            {
                                "_id": "5fe4977574f15b4ad31b66b7",
                                "_tpl": "5963866286f7747bf429b572"
                            },
                            {
                                "_id": "60dca3da42ad9b706b369aca",
                                "_tpl": "602543c13fee350cd564d032"
                            },
                            {
                                "_id": "f72a5eea10dd51cdff2426b4",
                                "_tpl": "56d59d3ad2720bdb418b4577",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "location": {
                                    "x": 2,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "fce1431d8a53b0affd4ef33a",
                                "_tpl": "58864a4f2459770fcc257101",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "location": {
                                    "x": 2,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "6973f3be1f471445de4d9724",
                                "_tpl": "58864a4f2459770fcc257101",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "location": {
                                    "x": 2,
                                    "y": 1,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "52392f34d3fe8cccc66dbc9d",
                                "_tpl": "58864a4f2459770fcc257101",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "location": {
                                    "x": 2,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "6c78b5483388b921ea0f97e7",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 0,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "1b22e2bfb298e7129a2308c0",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "6c78b5483388b921ea0f97e7",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "7e676ac39a5e3df88681a0f3",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "6c78b5483388b921ea0f97e7",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "49f0a4312241c6903839fce3",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "6c78b5483388b921ea0f97e7",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "dfade949b20b80d2c529500b",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 1,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "b119b18bad58f5a1cdda43b6",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "dfade949b20b80d2c529500b",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "4de3e17039bcd61f33bdfa5e",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "dfade949b20b80d2c529500b",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "86ad407c524a7e98e7d1b095",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "dfade949b20b80d2c529500b",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "8dbafe42141e42897a28a67d",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0c758b3fa94a0fc206db8314",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "8dbafe42141e42897a28a67d",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "a5b8d19808c3d86071f03f37",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "8dbafe42141e42897a28a67d",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "71fcea7acad3ff522162d0c1",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "8dbafe42141e42897a28a67d",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "54773ca6629cd42197918240",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "75e42ed3d44648c0aec084aa",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "54773ca6629cd42197918240",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "042d3209a52c96b064b3990e",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "54773ca6629cd42197918240",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "f1d69687355e20b4ee91bcd2",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "54773ca6629cd42197918240",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "3573c628906149c48aed18a2",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "FireMode": {
                                        "FireMode": "single"
                                    },
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "ef04fe565245686b553e3bfd",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "3573c628906149c48aed18a2",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "0768fb16d4918c9eb2551c77",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "3573c628906149c48aed18a2",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "7be020b7746989c49d3f316b",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "3573c628906149c48aed18a2",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "4d26203f17c408612d8df85a",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 86,
                                        "MaxDurability": 87
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 0,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "3bbdac2324bc649997bf7764",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "4d26203f17c408612d8df85a",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "f5f1a47e144629b53463bcec",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "4d26203f17c408612d8df85a",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "8cf0ac4d5ee398aecb54ac3d",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "4d26203f17c408612d8df85a",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "f26ec99c41044b9c72c966d8",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 1,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "4a94396858be9d53da7ce380",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "f26ec99c41044b9c72c966d8",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "34ea96a65177f48cdfce9c50",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "f26ec99c41044b9c72c966d8",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "b2bc882890435995671a778d",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "f26ec99c41044b9c72c966d8",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "4d335b84ae8e536f196584df",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 0,
                                    "y": 1,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "7c26a1ad89d5464b34df9a58",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "4d335b84ae8e536f196584df",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "38b219265f11b2d8653e46f8",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "4d335b84ae8e536f196584df",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "5a2d1c9ec56e70d8f637de9d",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "4d335b84ae8e536f196584df",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "1e6a7f491c00bf1dd2654480",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 100,
                                        "MaxDurability": 100
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 0,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "c999fb4b5ee77548bddbfa3f",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "1e6a7f491c00bf1dd2654480",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "8a7e1c73b0ef5abaa88bf667",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "1e6a7f491c00bf1dd2654480",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "666c428920ab9b4164dc7361",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "1e6a7f491c00bf1dd2654480",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "851de1688a25201b215b8641",
                                "_tpl": "624c2e8614da335f1e034d8c",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "sptPresetId": "624d7b2881a57812413b7954",
                                    "Repairable": {
                                        "Durability": 99,
                                        "MaxDurability": 99
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 1,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "9e2a7b5d56ed1782243c1523",
                                "_tpl": "624c3074dbbd335e8e6becf3",
                                "parentId": "851de1688a25201b215b8641",
                                "slotId": "mod_magazine",
                                "upd": {}
                            },
                            {
                                "_id": "af3207d96ff899d41f732c7f",
                                "_tpl": "619f4d304c58466fe1228437",
                                "parentId": "851de1688a25201b215b8641",
                                "slotId": "mod_sight_front",
                                "upd": {}
                            },
                            {
                                "_id": "10fbf9a8d557c3c475849840",
                                "_tpl": "619f4bffd25cbd424731fb97",
                                "parentId": "851de1688a25201b215b8641",
                                "slotId": "mod_pistol_grip",
                                "upd": {}
                            },
                            {
                                "_id": "f1d9e6d078800ea5a2c9fd5e",
                                "_tpl": "590c661e86f7741e566b646a",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "MedKit": {
                                        "HpResource": 220
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 4,
                                    "y": 2,
                                    "r": "Vertical",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "13b108a231a8dab6c71a6d53",
                                "_tpl": "590c661e86f7741e566b646a",
                                "upd": {
                                    "StackObjectsCount": 1,
                                    "MedKit": {
                                        "HpResource": 220
                                    }
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 3,
                                    "y": 2,
                                    "r": "Vertical",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0b88337e1b48d2cf743234cf",
                                "_tpl": "590c657e86f77412b013051d",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "2ea8c2e71968f169cc9db885",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "6ac0524fe5445653a891a069",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "7702a0b9f37e1142583db0e8",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "4144e2a0ada29f73f2681d74",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "2a47e1d49ad53f38762434a9",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "bcdf50ce93c9a30eac9ec39f",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "83f5e352b7657ffeef7d3b6e",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "74acab023b32b8d91aa9a1aa",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "11f12b6086d736c367b9b82c",
                                "_tpl": "56e33634d2720bd8058b456b",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 6,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "881995c196bb9a01aa86a156",
                                "_tpl": "56e33634d2720bd8058b456b",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 7,
                                    "y": 0,
                                    "r": 1,
                                    "rotation": true
                                }
                            },
                            {
                                "_id": "848c5afa6a291240d28c62c0",
                                "_tpl": "56e33634d2720bd8058b456b",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 6,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "d7e2363d3b46878d373ea1f9",
                                "_tpl": "58864a4f2459770fcc257101",
                                "upd": {
                                    "StackObjectsCount": 50
                                },
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 2,
                                    "y": 4,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "62d47895988d477532e2214f",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "bd2024f94830609ab55482fe",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 0,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "751a7af4186736e43c7ee928",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 1,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "ae3291566798c7ccdb39e02f",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 1,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "5c6a39b726eb75a718bd66b2",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "c9ca6621d09ec1653a2b51e3",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 3,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "7299e27a2ff61c69f47ad51a",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 5,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "cca77c07faffd61c58d2df3f",
                                "_tpl": "5b432f3d5acfc4704b4a1dfb",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 6,
                                    "y": 2,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "500866d97f1335bc212504a3",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 4,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "bba76a8b7fcac05ee1672f14",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 4,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "04370fc08895c0f7b4f53c7f",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "40ea95be0d3eddbe736b2113",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 3,
                                    "y": 5,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "7773f0cf0e03515dd8ee5042",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 5,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "48503ff6c2d86240728a52cf",
                                "_tpl": "544fb3364bdc2d34748b456a",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "0516d9557b7a015b3ea21e84",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "39a91673da031fe35bf4d339",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 5,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "a0a93caedaf9f9d87958f7b5",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 2,
                                    "y": 6,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "d9ef7b5e8b9476d7071b35a6",
                                "_tpl": "544fb25a4bdc2dfb738b4567",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 4,
                                    "y": 7,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "e38943e9fedfda8148c9b67e",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 7,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "db28c8fb645e4c817573cecc",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 7,
                                    "r": 0,
                                    "rotation": false
                                }
                            },
                            {
                                "_id": "9ac2f433ece7acf5fe11fd60",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 1,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "2084016cd18485efebb94fc5",
                                "_tpl": "5e831507ea0a7c419c2f9bd9",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "upd": {
                                    "StackObjectsCount": 1
                                },
                                "location": {
                                    "x": 0,
                                    "y": 8,
                                    "r": "Horizontal",
                                    "isSearched": true
                                }
                            },
                            {
                                "_id": "66a57348010019812987dc34",
                                "_tpl": "5449016a4bdc2d6f028b456f",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 9,
                                    "y": 10,
                                    "r": "Horizontal",
                                    "isSearched": true
                                },
                                "upd": {
                                    "StackObjectsCount": -2500000,
                                    "SpawnedInSession": false
                                }
                            },
                            {
                                "_id": "66a574b201001981294446c2",
                                "_tpl": "5449016a4bdc2d6f028b456f",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 8,
                                    "y": 10,
                                    "r": "Horizontal",
                                    "isSearched": true
                                },
                                "upd": {
                                    "StackObjectsCount": -2500000,
                                    "SpawnedInSession": false
                                }
                            },
                            {
                                "_id": "66a574b50100198129785edd",
                                "_tpl": "5449016a4bdc2d6f028b456f",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 7,
                                    "y": 10,
                                    "r": "Horizontal",
                                    "isSearched": true
                                },
                                "upd": {
                                    "StackObjectsCount": -2500000,
                                    "SpawnedInSession": false
                                }
                            },
                            {
                                "_id": "66a574bc0100198129c9a0ab",
                                "_tpl": "5449016a4bdc2d6f028b456f",
                                "parentId": "5fe4977574f15b4ad31b66b6",
                                "slotId": "hideout",
                                "location": {
                                    "x": 6,
                                    "y": 10,
                                    "r": "Horizontal",
                                    "isSearched": true
                                },
                                "upd": {
                                    "StackObjectsCount": -2500000,
                                    "SpawnedInSession": false
                                }
                            }
                        ],
                        "questRaidItems": "5fe4977574f15b4ad31b66b7",
                        "questStashItems": "5fe4977574f15b4ad31b66b8",
                        "sortingTable": "60dca3da42ad9b706b369aca",
                        "stash": "5fe4977574f15b4ad31b66b6"
                    },
                    "Notes": {
                        "Notes": []
                    },
                    "Quests": [],
                    "RagfairInfo": {
                        "isRatingGrowing": true,
                        "offers": [],
                        "rating": 0.2
                    },
                    "Skills": {
                        "Common": [{
                            "Id": "BotReload",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "BotSound",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Endurance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Strength",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Vitality",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Health",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "StressResistance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Metabolism",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Immunity",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Perception",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Intellect",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Attention",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Charisma",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Memory",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Pistol",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Revolver",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "SMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Assault",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Shotgun",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Sniper",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "LMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HMG",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Launcher",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AttachedLauncher",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Throwing",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Melee",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "DMR",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "RecoilControl",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AimDrills",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "TroubleShooting",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Surgery",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "CovertMovement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Search",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "MagDrills",
                            "LastAccess": -2147483648,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Sniping",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "ProneMovement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "FieldMedicine",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "FirstAid",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "LightVests",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HeavyVests",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "WeaponModding",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "AdvancedModding",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "NightOps",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "SilentOps",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Lockpicking",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "WeaponTreatment",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Freetrading",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Auctions",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Cleanoperations",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Barter",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Shadowconnections",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Taskperformance",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "Crafting",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "HideoutManagement",
                            "LastAccess": 0,
                            "PointsEarnedDuringSession": 0,
                            "Progress": 0
                        }, {
                            "Id": "BearAssaultoperations",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearAuthority",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearAksystems",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearHeavycaliber",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }, {
                            "Id": "BearRawpower",
                            "Progress": 0,
                            "PointsEarnedDuringSession": 0,
                            "LastAccess": 0
                        }
                        ],
                        "Mastering": [],
                        "Points": 0
                    },
                    "Stats": {
                        "Eft": {
                            "Aggressor": null,
                            "CarriedQuestItems": [],
                            "DamageHistory": {
                                "BodyParts": [],
                                "LethalDamage": null,
                                "LethalDamagePart": "Head"
                            },
                            "DroppedItems": [],
                            "ExperienceBonusMult": 0,
                            "FoundInRaidItems": [],
                            "LastPlayerState": null,
                            "LastSessionDate": 0,
                            "OverallCounters": {
                                "Items": []
                            },
                            "SessionCounters": null,
                            "SessionExperienceMult": 0,
                            "SurvivorClass": "Unknown",
                            "TotalInGameTime": 0,
                            "TotalSessionExperience": 0,
                            "Victims": []
                        }
                    },
                    "TradersInfo": {},
                    "UnlockedInfo": {
                        "unlockedProductionRecipe": []
                    },
                    "moneyTransferLimitData": {
                        "nextResetTime": 1717779074,
                        "remainingLimit": 1000000,
                        "totalLimit": 1000000,
                        "resetInterval": 86400
                    },
                    "WishList": [],
                    "_id": "__REPLACEME__",
                    "aid": "__REPLACEME__",
                    "savage": "__REPLACEME__"
                },
                "dialogues": {},
                "equipmentBuilds": {},
                "suits": [
                    "5cde9ec17d6c8b04723cf479",
                    "5cde9e957d6c8b0474535da7"
                ],
                "trader": {
                    "initialLoyaltyLevel": {
                        "54cb50c76803fa8b248b4571": 1,
                        "54cb57776803fa99248b456e": 1,
                        "579dc571d53a0658a154fbec": 1,
                        "58330581ace78e27b8b10cee": 1,
                        "5935c25fb3acc3127c3d8cd9": 1,
                        "5a7c2eca46aef81a7ca2145d": 1,
                        "5ac3b934156ae10c4430e83c": 1,
                        "5c0647fdd443bc2504c2d371": 1,
                        "638f541a29ffd1183d187f57": 1
                    },
                    "initialStanding": {
                        "default": 0.0,
                        "54cb50c76803fa8b248b4571": -0.3,
                        "54cb57776803fa99248b456e": -0.3,
                        "579dc571d53a0658a154fbec": -6,
                        "58330581ace78e27b8b10cee": -0.3,
                        "5935c25fb3acc3127c3d8cd9": -0.3,
                        "5a7c2eca46aef81a7ca2145d": -0.3,
                        "5ac3b934156ae10c4430e83c": -0.3,
                        "5c0647fdd443bc2504c2d371": -0.3,
                        "638f541a29ffd1183d187f57": 0.01
                    },
                    "initialSalesSum": 0,
                    "jaegerUnlocked": false,
                    "lockedByDefaultOverride": [
                        "579dc571d53a0658a154fbec"
                    ]
                },
                "weaponbuilds": {}
            }
        }
        this.logger.logWithColor(`[Choice Bound] [Storage = Power] enabled`, LogTextColor.MAGENTA);
    }
}